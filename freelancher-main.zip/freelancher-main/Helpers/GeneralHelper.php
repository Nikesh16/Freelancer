<?php

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;


if (!function_exists('generateUniqueSlug')) {
    function generateUniqueSlug($model, $title, $separator = '-')
    {
        $slug = Str::slug($title);
        $i = 0;

        while ($model::where('slug', $slug)->exists()) {
            $slug = Str::slug($title, $separator) . $separator . time() . ($i > 0 ? $separator . $i : '');
            $i++;
        }

        return $slug;
    }
}

if (!function_exists('upload_multiple_files')) {
    function upload_multiple_files($file, $filename)
    {
        $fileExt = ['jpeg', 'jpg', 'png', 'webp', 'bmp', 'pdf'];

        $ext = $file->getClientOriginalExtension();

        $ext = strtolower($ext);

        if (in_array($ext, $fileExt)) {

            $randVal = substr(hash_value(rand_num(4)), 0, 10);

            $newFileName = $filename . '_' . $randVal . '.' . $ext;

            $fileUploaded = $file->storeAs('upload', $newFileName, ['disk' => 'public']);

            return $fileUploaded;
        }

        return null;
    }
}

if (!function_exists('rand_num')) {
    function rand_num($val = 8)
    {
        $characters = '78965412309874563210741025896332569874101472583690123456789987654321014702583699512365478975623148967';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $val; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}

if (!function_exists('hash_value')) {
    function hash_value($val)
    {
        return hash('gost', $val);
    }
}

if (!function_exists('UpdateUserBalance')) {
    function UpdateUserBalance($amount, $operation, $user_id, $remarks = null)
    {
        try {
            $user = User::findOrFail($user_id);
            if ($operation == 'add') {
                $user->increaseBalance($amount * 100, [
                    'description' => $remarks,
                ]);

                $deposite_amout = $amount * 100;

                $user->deposit($deposite_amout);
            } else if ($operation == 'deduct') {
                $user->decreaseBalance($amount * 100, [
                    'description' => $remarks,
                ]);

                $deposite_amout = $amount * 100;

                $user->withdraw($deposite_amout);
                
            } else if ($operation == 'adjust') {
                $reset_amount = $amount * 100 - $user->balance * 100;
                $user->modifyBalance($reset_amount, [
                    'description' => $remarks . ' (Adjusted)',
                ]);
            } else if ($operation == 'reset') {
                $user->resetBalance();
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
