<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notice\Notice;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class NoticeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $notices = (new Notice())->newQuery();

        if (request()->has('search')) {
            $notices->where('title', 'Like', '%' . request()->input('search') . '%');
        }

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $notices->orderBy($attribute, $sort_order);
        } else {
            $notices->latest();
        }

        $notices = $notices->paginate(config('admin.paginate.per_page'))
        ->onEachSide(config('admin.paginate.each_side'))
        ->appends(request()->query());

        return Inertia::render('Admin/Notice/Index', [
            'notices' => $notices,
            'filters' => request()->all('search')
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('Admin/Notice/Create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'image' => 'nullable|file|max:2048',
        ]);

        try {
            DB::beginTransaction();

            if ($request->image) {
                $notice_image = upload_multiple_files($request->image, 'notice_image');
            } else {
                $notice_image = null;
            }
            $new_notice = Notice::create([
                'title' => $request->title,
                'description' => $request->description,
                'image' => $notice_image,
                'status' => $request->status?$request->status:0,
            ]);

            DB::commit();

            if ($new_notice) {
                return redirect()->route('admin.notice.index')->with('message', 'Notice create successfully');
            } else {
                return redirect()->route('admin.notice.index')->with('error', 'Something went wrong.');
            }
        } catch (Exception $e) {

            return redirect()->route('admin.notice.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $notice = Notice::where('id', $id)->firstOrFail();

        return Inertia::render('Admin/Notice/Show', [
            'notice' => $notice
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $notice = Notice::where('id', $id)->firstOrFail();
        return Inertia::render('Admin/Notice/Edit', [
            'notice' => $notice
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validate = $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'image' => 'nullable|file|max:2048',
        ]);

        try {
            DB::beginTransaction();

            $notice = Notice::where('id', $id)->firstOrFail();

            if ($request->image) {
                $notice_image = upload_multiple_files($request->image, 'notice_image');
            } else {
                $notice_image = $notice->image;
            }

            $notice->update([
                'title' => $request->title,
                'description' => $request->description,
                'image' => $notice_image,
                'status' => $request->status?$request->status:0,
            ]);

            DB::commit();

            return redirect()->route('admin.notice.index')
                        ->with('message', __('Notice updated successfully.'));

        } catch (Exception $e) {

            return redirect()->route('admin.notice.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $notice = Notice::where('id',$id)->firstOrFail();

        $notice->delete();

        return redirect()->route('admin.notice.index')
                        ->with('message', __('Notice deleted successfully'));
    }
}
