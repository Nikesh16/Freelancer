<?php

namespace App\Http\Controllers\Blog;

use App\Http\Controllers\Controller;
use App\Models\Blog\Blog;
use App\Models\BlogCategory\BlogCategory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $blogs = (new Blog())->newQuery();

        if (request()->has('search')) {
            $blogs->where('name', 'Like', '%' . request()->input('search') . '%');
        }

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $blogs->orderBy($attribute, $sort_order);
        } else {
            $blogs->latest();
        }

        $blogs = $blogs->paginate(config('admin.paginate.per_page'))
        ->onEachSide(config('admin.paginate.each_side'))
        ->appends(request()->query());

        return Inertia::render('Admin/Blog/Index', [
            'blogs' => $blogs,
            'filters' => request()->all('search')
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $blog_category = BlogCategory::where('status', 1)->pluck('name', 'id');
        return Inertia::render('Admin/Blog/Create', [
            'blog_category' => $blog_category,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
            'image' => 'required|max:2048',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keyword' => 'nullable',
            'order' => 'nullable',
            'status' => 'nullable',
            'blog_category_id' => 'required',
        ]);


        if ($request->image) {
            $blog_image = upload_multiple_files($request->image, 'blog_image');
        } else {
            $blog_image = null;
        }

        try {
            DB::beginTransaction();
            $blog = Blog::create([
                'name' => $request->name,
                'description' => $request->description,
                'blog_category_id' => $request->blog_category_id,
                'image' => $blog_image,
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'meta_keyword' => $request->meta_keyword,
                'status' => $request->status ? $request->status : 0,
            ]);

            DB::commit();

            if ($blog) {
                return redirect()->route('admin.blog.index')->with('message', 'Blog  create successfully');
            } else {
                return redirect()->route('admin.blog.index')->with('error', 'Something went wrong.');
            }
        } catch (Exception $e) {

            return redirect()->route('admin.blog.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $blog = Blog::where('id', $id)->firstOrFail();

        return Inertia::render('Admin/Blog/Show', [
            'blog' => $blog
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $blog = Blog::where('id', $id)->firstOrFail();
        $blog_category = BlogCategory::where('status', 1)->pluck('name', 'id');

        return Inertia::render('Admin/Blog/Edit', [
            'blog' => $blog,
            'blog_category' => $blog_category,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
            'image' => 'nullable|max:2048',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keyword' => 'nullable',
            'order' => 'nullable',
            'status' => 'nullable',
            'blog_category_id' => 'required',
        ]);

        try {
            DB::beginTransaction();

            $blog = Blog::where('id', $id)->firstOrFail();


            if ($request->image) {
                $blog_image = upload_multiple_files($request->image, 'blog_image');
            } else {
                $blog_image = $blog->image;
            }
            $blog->update([
                'name' => $request->name,
                'description' => $request->description,
                'blog_category_id' => $request->blog_category_id,
                'image' => $blog_image,
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'meta_keyword' => $request->meta_keyword,
                'status' => $request->status ? $request->status : 0,
            ]);

            DB::commit();

            return redirect()->route('admin.blog.index')
                ->with('message', __('Blog updated successfully.'));
        } catch (Exception $e) {

            return redirect()->route('admin.blog.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $blog = Blog::where('id', $id)->firstOrFail();

        $blog->delete();

        return redirect()->route('admin.blog.index')
            ->with('message', __('Blog deleted successfully'));
    }
}
