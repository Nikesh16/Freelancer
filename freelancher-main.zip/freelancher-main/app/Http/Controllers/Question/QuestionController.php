<?php

namespace App\Http\Controllers\Question;

use App\Http\Controllers\Controller;
use App\Models\Category\Category;
use App\Models\Question\Question;
use App\Models\Question\QuestionCatgory;
use App\Models\Question\QuestionOption;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $questions = (new Question())->newQuery();

        if (request()->has('search')) {
            $questions->where('question', 'Like', '%' . request()->input('search') . '%');
        }

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $questions->orderBy($attribute, $sort_order);
        } else {
            $questions->latest();
        }

        $questions = $questions->paginate(config('admin.paginate.per_page'))
            ->onEachSide(config('admin.paginate.each_side'))
            ->appends(request()->query());

        return Inertia::render('Admin/Question/Index', [
            'questions' => $questions,
            'filters' => request()->all('search')
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $category = Category::where('status', 1)->pluck('name', 'id');
        return Inertia::render('Admin/Question/Create', [
            'category' => $category,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'question' => 'required',
            'input_type' => 'required',
            'is_required' => 'nullable',
            'placeholder' => 'nullable',
            'input_text' => 'nullable',
            'label' => 'required',
            'category_id' => 'required',
            'status' => 'nullable',
        ]);

        try {
            DB::beginTransaction();
            $question = Question::create([
                'question' => $request->question,
                'input_type' => $request->input_type,
                'is_required' => $request->is_required,
                'placeholder' => $request->placeholder,
                'input_text' => $request->input_text,
                'input_id' => rand(0000, 9999),
                'status' => $request->status ? $request->status : 0,
                'label' => $request->label,
            ]);

            if ($question) {
                $question_category = QuestionCatgory::create([
                    'question_id' => $question->id,
                    'category_id' => $request->category_id,
                ]);
                if ($question->input_type == 'checkbox' || $question->input_type == 'radio' && $request->options) {
                    foreach ($request->options as $option_value) {
                        $question_options = QuestionOption::create([
                            'question_id' => $question->id,
                            'name' => $option_value['name'],
                            'value' => $option_value['value'],
                        ]);
                    }
                }
            }

            DB::commit();

            if ($question) {
                return redirect()->route('admin.question.index')->with('message', 'Question create successfully');
            } else {
                return redirect()->route('admin.question.index')->with('error', 'Something went wrong.');
            }
        } catch (Exception $e) {

            return redirect()->route('admin.question.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $question = Question::where('id', $id)->with('questionOptions', 'questionCategory')->firstOrFail();
        $category = Category::where('status', 1)->pluck('name', 'id');
        return Inertia::render('Admin/Question/Show', [
            'question' => $question,
            'category' => $category
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $question = Question::where('id', $id)->with('questionOptions', 'questionCategory')->firstOrFail();
        $category = Category::where('status', 1)->pluck('name', 'id');
        $QuestionOption = QuestionOption::where('question_id', $question->id)->get();
        return Inertia::render('Admin/Question/Edit', [
            'category' => $category,
            'question' => $question,
            'QuestionOption' => $QuestionOption,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validate = $request->validate([
            'question' => 'required',
            'input_type' => 'required',
            'is_required' => 'nullable',
            'placeholder' => 'nullable',
            'input_text' => 'nullable',
            'label' => 'required',
            'category_id' => 'required',
            'status' => 'nullable',
        ]);

        try {
            DB::beginTransaction();

            $question = Question::where('id', $id)->firstOrFail();


            $question->update([
                'question' => $request->question,
                'input_type' => $request->input_type,
                'is_required' => $request->is_required,
                'placeholder' => $request->placeholder,
                'input_text' => $request->input_text,
                'status' => $request->status ? $request->status : 0,
                'label' => $request->label,
            ]);

            if ($question) {
                $question_category = QuestionCatgory::where('question_id', $question->id)->first();

                if ($question_category) {
                    $question_category->update([
                        'category_id' => $request->category_id,
                    ]);
                }
                if ($question->input_type == 'checkbox' || $question->input_type == 'radio' && $request->options) {
                    foreach ($request->options as $option_value) {
                        if (isset($option_value['id'])) {
                            $QuestionOption = QuestionOption::where('id', $option_value['id'])->first();
                            if ($QuestionOption) {
                                $QuestionOption->update([
                                    'name' => $option_value['name'],
                                    'value' => $option_value['value'],
                                ]);
                            }
                        } else {
                            $question_options = QuestionOption::create([
                                'question_id' => $question->id,
                                'name' => $option_value['name'],
                                'value' => $option_value['value'],
                            ]);
                        }
                    }
                }
            }


            DB::commit();

            return redirect()->route('admin.question.index')
                ->with('message', __('Question updated successfully.'));
        } catch (Exception $e) {

            return redirect()->route('admin.question.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $question = Question::where('id', $id)->firstOrFail();

        $question->delete();

        return redirect()->route('admin.question.index')
            ->with('message', __('Question deleted successfully'));
    }
}
