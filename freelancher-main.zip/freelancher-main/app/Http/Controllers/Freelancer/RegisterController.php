<?php

namespace App\Http\Controllers\Freelancher;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Inertia\Inertia;

class RegisterController extends Controller
{
    public function register()
    {
        return Inertia::render('Freelancer/register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'type' => 'required',
            'docs' => 'required|max:2048',
            'total_team' => 'nullable',
            'password' => 'required|min:6',
        ]);
    }
}
