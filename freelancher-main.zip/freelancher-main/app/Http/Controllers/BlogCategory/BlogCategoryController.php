<?php

namespace App\Http\Controllers\BlogCategory;

use App\Http\Controllers\Controller;
use App\Models\BlogCategory\BlogCategory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class BlogCategoryController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $blog_categories = (new BlogCategory())->newQuery();

        if (request()->has('search')) {
            $blog_categories->where('name', 'Like', '%' . request()->input('search') . '%');
        }

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $blog_categories->orderBy($attribute, $sort_order);
        } else {
            $blog_categories->latest();
        }

        $blog_categories = $blog_categories->paginate(5)->onEachSide(2)->appends(request()->query());

        return Inertia::render('Admin/BlogCategory/Index', [
            'blog_categories' => $blog_categories,
            'filters' => request()->all('search')
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('Admin/BlogCategory/Create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
        ]);

        try {
            DB::beginTransaction();
            $blog_category = BlogCategory::create([
                'name' => $request->name,
                'description' => $request->description,
                'status' => $request->status?$request->status:0,
            ]);

            DB::commit();

            if ($blog_category) {
                return redirect()->route('admin.blog_category.index')->with('message', 'Blog Category create successfully');
            } else {
                return redirect()->route('admin.blog_category.index')->with('error', 'Something went wrong.');
            }
        } catch (Exception $e) {

            return redirect()->route('admin.blog_category.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $blog_category = BlogCategory::where('id', $id)->firstOrFail();

        return Inertia::render('Admin/BlogCategory/Show', [
            'blog_category' => $blog_category
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $blog_category = BlogCategory::where('id', $id)->firstOrFail();
        return Inertia::render('Admin/BlogCategory/Edit', [
            'blog_category' => $blog_category
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
        ]);

        try {
            DB::beginTransaction();

            $blog_category = BlogCategory::where('id', $id)->firstOrFail();


            $blog_category->update([
                'name' => $request->name,
                'description' => $request->description,
                'status' => $request->status?$request->status:0,
            ]);

            DB::commit();

            return redirect()->route('admin.blog_category.index')
                        ->with('message', __('Blog Category updated successfully.'));

        } catch (Exception $e) {

            return redirect()->route('blog_category.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $blog_category = BlogCategory::where('id',$id)->firstOrFail();

        $blog_category->delete();

        return redirect()->route('admin.blog_category.index')
                        ->with('message', __('Blog Category deleted successfully'));
    }
}
