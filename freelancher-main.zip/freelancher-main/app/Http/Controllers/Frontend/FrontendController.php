<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Inertia\Inertia;

class FrontendController extends Controller
{
    // public function index()
    // {
    //     return Inertia::render('Welcome', [
    //         'canLogin' => Route::has('login'),
    //         'canRegister' => Route::has('register'),
    //         'phpVersion' => PHP_VERSION,
    //     ]);
    // }

    public function questionModule()
    {
        return Inertia::render('Frontend/Pages/QuestionModule');
    }

}
