<?php

namespace App\Http\Controllers\Category;

use App\Http\Controllers\Controller;
use App\Models\Category\Category;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class ChildCategoryController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = (new Category())->newQuery();

        if (request()->has('search')) {
            $categories->where('name', 'Like', '%' . request()->input('search') . '%')->where('is_child_category',1);
        }

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $categories->orderBy($attribute, $sort_order);
        } else {
            $categories->latest();
        }

        $categories = $categories->where('is_child_category',1)->paginate(config('admin.paginate.per_page'))
        ->onEachSide(config('admin.paginate.each_side'))
        ->appends(request()->query());

        return Inertia::render('Admin/ChildCategory/Index', [
            'categories' => $categories,
            'filters' => request()->all('search')
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $category = Category::where('status',1)->whereNotNull('parent_id')->where('is_sub_category',1)->pluck('name','id');
        return Inertia::render('Admin/ChildCategory/Create',[
            'category' => $category,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
            'image' => 'required|max:2048',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keyword' => 'nullable',
            'order' => 'nullable',
            'status' => 'nullable',
            'parent_id' => 'required',
        ]);


        if ($request->image) {
            $category_image = upload_multiple_files($request->image, 'category_image');
        } else {
            $category_image = null;
        }

        try {
            DB::beginTransaction();
            $category = Category::create([
                'name' => $request->name,
                'description' => $request->description,
                'image' => $category_image,
                'meta_title' => $request->meta_title,
                'is_child_category' => 1,
                'parent_id' => $request->parent_id,
                'meta_description' => $request->meta_description,
                'meta_keyword' => $request->meta_keyword,
                'status' => $request->status ? $request->status : 0,
                'is_location_required' => $request->is_location_required?$request->is_location_required:0,
            ]);

            DB::commit();

            if ($category) {
                return redirect()->route('admin.child_category.index')->with('message', 'Child Category create successfully');
            } else {
                return redirect()->route('admin.child_category.index')->with('error', 'Something went wrong.');
            }
        } catch (Exception $e) {

            return redirect()->route('admin.child_category.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $category = Category::where('id', $id)->firstOrFail();

        return Inertia::render('Admin/ChildCategory/Show', [
            'category' => $category
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $category = Category::where('id', $id)->firstOrFail();
        $parent_category = Category::where('status',1)->whereNotNull('parent_id')->where('is_sub_category',1)->pluck('name','id');
        return Inertia::render('Admin/SubCategory/Edit', [
            'category' => $category,
            'parent_category' => $parent_category,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validate = $request->validate([
            'name' => 'required',
            'description' => 'nullable',
            'image' => 'nullable|max:2048',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keyword' => 'nullable',
            'order' => 'nullable',
            'status' => 'nullable',
            'parent_id' => 'required',
        ]);

        try {
            DB::beginTransaction();

            $category = Category::where('id', $id)->firstOrFail();


            if ($request->image) {
                $category_image = upload_multiple_files($request->image, 'category_image');
            } else {
                $category_image = $category->image;
            }
            $category->update([
                'name' => $request->name,
                'description' => $request->description,
                'image' => $category_image,
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'is_child_category' => 1,
                'parent_id' => $request->parent_id,
                'meta_keyword' => $request->meta_keyword,
                'status' => $request->status ? $request->status : 0,
                'is_location_required' => $request->is_location_required?$request->is_location_required:0,
            ]);

            DB::commit();

            return redirect()->route('admin.child_category.index')
                ->with('message', __('Child Category updated successfully.'));
        } catch (Exception $e) {

            return redirect()->route('child_category.index')->with('error', 'Something went wrong.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $child_category = Category::where('id', $id)->firstOrFail();

        $child_category->delete();

        return redirect()->route('admin.child_category.index')
            ->with('message', __('Child Category deleted successfully'));
    }
}
