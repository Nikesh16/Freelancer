<?php

namespace App\Models\BlogCategory;

use App\Models\Blog\Blog;
use App\Models\GeneralBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BlogCategory extends GeneralBaseModel
{
    use HasFactory,SoftDeletes;

    protected $table = 'blog_categories';

    public function blogs()
    {
        return $this->hasOne(Blog::class,'blog_id','id');
    }
}
