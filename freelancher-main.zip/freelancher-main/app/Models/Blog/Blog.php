<?php

namespace App\Models\Blog;

use App\Models\BlogCategory\BlogCategory;
use App\Models\GeneralBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends GeneralBaseModel
{
    use HasFactory,SoftDeletes;

    protected $table = 'blogs';

    public function category()
    {
        return $this->hasOne(BlogCategory::class,'id','blog_category_id');
    }
}
