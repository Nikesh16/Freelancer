<?php

namespace App\Models\Question;

use App\Models\GeneralBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionCatgory extends GeneralBaseModel
{
    use HasFactory;

    protected $table = 'question_catgories';
}
