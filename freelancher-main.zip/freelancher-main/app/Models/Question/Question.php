<?php

namespace App\Models\Question;

use App\Models\GeneralBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Question extends GeneralBaseModel
{
    use HasFactory,SoftDeletes;

    protected $table = 'questions';

    public function questionCategory()
    {
        return $this->hasOne(QuestionCatgory::class,'question_id');
    }

    public function questionOptions()
    {
        return $this->hasMany(QuestionOption::class,"question_id");
    }
}
