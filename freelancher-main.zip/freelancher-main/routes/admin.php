<?php

use App\Http\Controllers\Blog\BlogController;
use App\Http\Controllers\BlogCategory\BlogCategoryController;
use App\Http\Controllers\Category\ChildCategoryController;
use App\Http\Controllers\Category\ParentCategoryController;
use App\Http\Controllers\Category\SubCategoryController;
use App\Http\Controllers\Location\LocationController;
use Inertia\Inertia;

Route::group([
    'namespace' => 'App\Http\Controllers\Admin',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::get('/', function () {
        return Inertia::render('Admin/Dashboard');
    })->name('dashboard');    
    Route::resource('user', 'UserController');
    Route::resource('role', 'RoleController');
    Route::resource('permission', 'PermissionController');
    Route::resource('menu', 'MenuController')->except([
        'show',
    ]);
    Route::resource('menu.item', 'MenuItemController');
    // Route::group([
    //     'prefix' => 'category',
    //     'as' => 'category.',
    // ], function () {
    //     Route::resource('type', 'CategoryTypeController')->except([
    //         'show',
    //     ]);
    //     Route::resource('type.item', 'CategoryController');
    // });
    Route::get('edit-account-info', 'UserController@accountInfo')->name('account.info');
    Route::post('edit-account-info', 'UserController@accountInfoStore')->name('account.info.store');
    Route::post('change-password', 'UserController@changePasswordStore')->name('account.password.store');

    Route::resource('notice', 'NoticeController');

});

Route::group([
    'namespace' => 'App\Http\Controllers\Location',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::resource('location', 'LocationController');
});

Route::group([
    'namespace' => 'App\Http\Controllers\BlogCategory',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::resource('blog_category', 'BlogCategoryController');
});
Route::group([
    'namespace' => 'App\Http\Controllers\Blog',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::resource('blog', 'BlogController');
});

Route::group([
    'namespace' => 'App\Http\Controllers\Question',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::resource('question', 'QuestionController');
});

Route::group([
    'namespace' => 'App\Http\Controllers\Category',
    'prefix' => config('admin.prefix'),
    'middleware' => ['auth'],
    'as' => 'admin.',
], function () {
    Route::resource('category', 'ParentCategoryController');
    Route::resource('sub_category', 'SubCategoryController');
    Route::resource('child_category', 'ChildCategoryController');
});
