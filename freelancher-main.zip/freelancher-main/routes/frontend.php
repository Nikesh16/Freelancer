<?php

use App\Http\Controllers\Admin\ContactRequestController;
use App\Http\Controllers\Frontend\FrontendController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

// Route::get('/', [FrontendController::class, 'index'])->name('welcomePage');
Route::get('/question-module', [FrontendController::class, 'questionModule'])->name('questionModule');
