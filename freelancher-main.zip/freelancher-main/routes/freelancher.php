<?php

use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;

Route::group([
    'namespace' => 'App\Http\Controllers\Freelancer',
    'prefix' => 'freelancer',
    'as' => 'freelancer.',
], function () {
    Route::get('register-freelancer', 'RegisterController@register');
    Route::post('register-freelancer', 'RegisterController@store');
});
