<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
const props = defineProps({
    blogData: {
        type: Object,
        default: () => ({}),
    },
});
const ablogs = [1, 2, 3, 4, 5, 6]
</script>
<template>
    <div>
        <div class="banner container">
            <div class="banner-wrap bg-lightsecondary pl-8 py-8">
                <div class="grid lg:grid-cols-2 grid-cols-1 gap-4 items-center">
                    <div class="left relative">
                        <div class="flex justify-around items-center">
                            <div class="left-wrap flex flex-shrink-0 gap-6 flex-col">
                                <div class="batch bg-lightprimary px-3 rounded-full text-primary max-w-max">
                                    <span>Search</span>
                                </div>
                                <h2 class="sm:text-4xl text-2xl font-bold">
                                    Get Started With <br> Ruby Today!
                                </h2>
                                <h3>
                                    In the ever-evolving landscape of skills and <br> knowledge.
                                </h3>
                                <button class="px-6 py-3 max-w-max bg-primary rounded-full text-white text-lg">
                                    Browse More
                                </button>
                            </div>
                            <div class="flex flex-col gap-4 lg:flex hidden justify-center items-center">
                                <img src="/images/icons/bannericon.png" class="w-[118px]" alt="">
                                <img src="/images/icons/noto_fire.png" alt="">
                                <img src="/images/icons/bannerprofile.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="right">
                        <img src="/images/icons/bannerimage.png" class="w-full" alt="">
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- <RequestForm /> -->
</template>
