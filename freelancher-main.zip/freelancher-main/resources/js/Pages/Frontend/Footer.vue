<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { computed, onMounted, onUnmounted } from 'vue';
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import NotificationBar from "@/Components/NotificationBar.vue"
const form = useForm({
    email: '',
})
const page = usePage()

const general_setting = computed(() => page.props.general_setting.setting);

</script>
<template>
    <div>
        <NotificationBar :key="Date.now()" v-if="$page.props.flash.message" color="success" :icon="mdiAlertBoxOutline">
            {{ $page.props.flash.message }}
        </NotificationBar>
        <footer class="  border-t  border-gray-200">
            <div class="container mt-4 mx-auto">
                <div class="grid grid-cols-12">
                    <div class="w-full xl:col-span-4 col-span-12">
                        <div class="pr-2">
                            <div class="mt-2">
                                <Link :href="'/'" class="flex  items-center gap-4">
                                <svg width="45" height="45" viewBox="0 0 45 45" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect width="45" height="45" rx="9" fill="#FF9800" />
                                    <path
                                        d="M15.04 17L13.288 13.82H12.796V17H10.744V8.576H14.188C14.852 8.576 15.416 8.692 15.88 8.924C16.352 9.156 16.704 9.476 16.936 9.884C17.168 10.284 17.284 10.732 17.284 11.228C17.284 11.788 17.124 12.288 16.804 12.728C16.492 13.168 16.028 13.48 15.412 13.664L17.356 17H15.04ZM12.796 12.368H14.068C14.444 12.368 14.724 12.276 14.908 12.092C15.1 11.908 15.196 11.648 15.196 11.312C15.196 10.992 15.1 10.74 14.908 10.556C14.724 10.372 14.444 10.28 14.068 10.28H12.796V12.368Z"
                                        fill="#FF9800" />
                                    <path
                                        d="M27.76 8.576V13.616C27.76 14.12 27.884 14.508 28.132 14.78C28.38 15.052 28.744 15.188 29.224 15.188C29.704 15.188 30.072 15.052 30.328 14.78C30.584 14.508 30.712 14.12 30.712 13.616V8.576H32.764V13.604C32.764 14.356 32.604 14.992 32.284 15.512C31.964 16.032 31.532 16.424 30.988 16.688C30.452 16.952 29.852 17.084 29.188 17.084C28.524 17.084 27.928 16.956 27.4 16.7C26.88 16.436 26.468 16.044 26.164 15.524C25.86 14.996 25.708 14.356 25.708 13.604V8.576H27.76Z"
                                        fill="#FF9800" />
                                    <path
                                        d="M15.844 30.68C16.332 30.784 16.724 31.028 17.02 31.412C17.316 31.788 17.464 32.22 17.464 32.708C17.464 33.412 17.216 33.972 16.72 34.388C16.232 34.796 15.548 35 14.668 35H10.744V26.576H14.536C15.392 26.576 16.06 26.772 16.54 27.164C17.028 27.556 17.272 28.088 17.272 28.76C17.272 29.256 17.14 29.668 16.876 29.996C16.62 30.324 16.276 30.552 15.844 30.68ZM12.796 29.984H14.14C14.476 29.984 14.732 29.912 14.908 29.768C15.092 29.616 15.184 29.396 15.184 29.108C15.184 28.82 15.092 28.6 14.908 28.448C14.732 28.296 14.476 28.22 14.14 28.22H12.796V29.984ZM14.308 33.344C14.652 33.344 14.916 33.268 15.1 33.116C15.292 32.956 15.388 32.728 15.388 32.432C15.388 32.136 15.288 31.904 15.088 31.736C14.896 31.568 14.628 31.484 14.284 31.484H12.796V33.344H14.308Z"
                                        fill="#FF9800" />
                                    <path
                                        d="M31.968 26.576L29.052 32.216V35H27V32.216L24.084 26.576H26.412L28.044 30.104L29.664 26.576H31.968Z"
                                        fill="#FF9800" />
                                    <path
                                        d="M24.4 30L21.48 24.7H20.66V30H17.24V15.96H22.98C24.0867 15.96 25.0267 16.1533 25.8 16.54C26.5867 16.9267 27.1733 17.46 27.56 18.14C27.9467 18.8067 28.14 19.5533 28.14 20.38C28.14 21.3133 27.8733 22.1467 27.34 22.88C26.82 23.6133 26.0467 24.1333 25.02 24.44L28.26 30H24.4ZM20.66 22.28H22.78C23.4067 22.28 23.8733 22.1267 24.18 21.82C24.5 21.5133 24.66 21.08 24.66 20.52C24.66 19.9867 24.5 19.5667 24.18 19.26C23.8733 18.9533 23.4067 18.8 22.78 18.8H20.66V22.28Z"
                                        fill="white" />
                                </svg>
                                <span class="font-bold">RUBY</span>
                                </Link>
                            </div>
                            <div class=" mt-3 text-textcolor ">It is a long established fact that from
                                will be distracted by the readable
                                from when looking It is a long established fact that from
                                will be distracted by the readable
                                from when looking..
                            </div>
                            <ul class="flex gap-2 flex-col mt-4">
                                <li class="flex items-center gap-1">
                                    <span>
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M2.99896 3.00024H14.999C15.824 3.00024 16.499 3.67524 16.499 4.50024V13.5002C16.499 14.3252 15.824 15.0002 14.999 15.0002H2.99896C2.17396 15.0002 1.49896 14.3252 1.49896 13.5002V4.50024C1.49896 3.67524 2.17396 3.00024 2.99896 3.00024Z"
                                                stroke="#FF9800" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M16.499 4.5L8.99896 9.75L1.49896 4.5" stroke="#FF9800"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>

                                    </span>
                                    <span>
                                        freelancer@gmail.com
                                    </span>
                                </li>
                                <li class="flex items-center gap-1">
                                    <span>
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_264_63)">
                                                <path
                                                    d="M11.9143 3.95866C12.6876 4.10952 13.3982 4.4877 13.9553 5.04477C14.5124 5.60185 14.8905 6.31249 15.0414 7.08574L11.9143 3.95866ZM11.9143 0.791992C13.5208 0.970463 15.0189 1.68988 16.1626 2.83212C17.3063 3.97437 18.0276 5.47154 18.2081 7.07783L11.9143 0.791992ZM17.4164 13.3953V15.7703C17.4173 15.9908 17.3721 16.209 17.2838 16.4111C17.1955 16.6131 17.0659 16.7944 16.9035 16.9435C16.741 17.0925 16.5492 17.206 16.3403 17.2766C16.1315 17.3473 15.9101 17.3735 15.6906 17.3537C13.2545 17.089 10.9144 16.2565 8.85847 14.9232C6.94567 13.7078 5.32395 12.086 4.10847 10.1732C2.77054 8.10795 1.93792 5.75653 1.67806 3.30949C1.65827 3.09057 1.68429 2.86993 1.75445 2.66161C1.82461 2.4533 1.93738 2.26187 2.08558 2.09953C2.23378 1.93718 2.41415 1.80747 2.61522 1.71866C2.8163 1.62984 3.03366 1.58387 3.25347 1.58366H5.62847C6.01267 1.57988 6.38514 1.71593 6.67645 1.96646C6.96776 2.21698 7.15803 2.56489 7.21181 2.94533C7.31205 3.70538 7.49795 4.45165 7.76597 5.16991C7.87249 5.45327 7.89554 5.76122 7.8324 6.05727C7.76926 6.35333 7.62257 6.62508 7.40972 6.84033L6.40431 7.84574C7.53129 9.82772 9.17233 11.4688 11.1543 12.5957L12.1597 11.5903C12.375 11.3775 12.6467 11.2308 12.9428 11.1676C13.2388 11.1045 13.5468 11.1276 13.8301 11.2341C14.5484 11.5021 15.2947 11.688 16.0547 11.7882C16.4393 11.8425 16.7905 12.0362 17.0416 12.3325C17.2926 12.6288 17.426 13.0071 17.4164 13.3953Z"
                                                    stroke="#FF9800" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_264_63">
                                                    <rect width="19" height="19" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>

                                    </span>
                                    <span>
                                        +7 5749575575
                                    </span>
                                </li>
                            </ul>

                        </div>
                    </div>

                    <div class="mt-6 xl:mt-0 xl:col-span-8 col-span-12">
                        <div class="grid grid-cols-1 gap-6  lg:grid-cols-3 md:grid-cols-2">
                            <div>
                                <div class="text-textcolor font-bold ">Pages</div>
                                <ul>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Home</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        About Us
                                        </Link>
                                    </li>
                                    <li>
                                        <Link
                                            class="block mt-2 text-primary  font-bold hover:text-gray-700 duration-500  ">
                                        How It Works</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Jobs
                                        </Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Blogs
                                        </Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        COntact Us
                                        </Link>
                                    </li>
                                </ul>
                            </div>


                            <div>
                                <div class="text-textcolor font-bold ">Utility Pages</div>
                                <ul>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Privacy</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Terms and Condition</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Private</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Policy</Link>
                                    </li>
                                    <li>
                                        <Link class="block mt-2  text-textcolor hover:text-gray-700 duration-500  ">
                                        Licences</Link>
                                    </li>
                                </ul>

                            </div>

                            <div>
                                <img src="/images/icons/appdownload.png" alt="">
                            </div>

                        </div>
                    </div>
                </div>

                <hr class="h-px my-6 bg-gray-200 border-none ">
                <div class="flex justify-between w-full">
                    <div class="text-center text-textcolor ">Copyright © Ruby | - All Rights Reserve</div>
                    <div>
                        <div class="flex gap-4 items-center ">
                            <a href="#"
                                class=" text-gray-600 bg-[#316FF6] w-7 h-7 rounded-full flex justify-center items-center transition-colors duration-300  hover:text-blue-500 ">
                                <svg width="9" height="16" viewBox="0 0 11 19" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path class="hover:scale-110 duration-300"
                                        d="M7.31339 18.395V10.1844H10.2081L10.6415 6.98452H7.31331V4.94155C7.31331 4.01512 7.58348 3.38381 8.97893 3.38381L10.7586 3.38301V0.521091C10.4508 0.482165 9.39429 0.39502 8.16531 0.39502C5.59929 0.39502 3.84255 1.88619 3.84255 4.62474V6.98452H0.94043V10.1844H3.84255V18.3949H7.31339V18.395Z"
                                        fill="#fff" />
                                </svg>
                            </a>

                            <a href="#"
                                class=" text-gray-600 bg-[#f2a60c] w-7 h-7 rounded-full flex justify-center items-center transition-colors duration-300  hover:text-blue-500 ">
                                <svg width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <path class="hover:scale-110 duration-300"
                                        d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"
                                        fill="#fff" />
                                </svg>
                            </a>

                            <a href="#"
                                class=" text-gray-600 transition-colors bg-[#0077b5] w-7 h-7 rounded-full flex justify-center items-center duration-300  hover:text-blue-500 ">
                                <svg width="14" height="14" viewBox="0 0 19 19" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path class="hover:scale-110 duration-300"
                                        d="M0.849609 3.31507C0.849609 2.73786 1.05232 2.26167 1.45772 1.8865C1.86312 1.51131 2.39016 1.32373 3.0388 1.32373C3.67587 1.32373 4.1913 1.50842 4.58513 1.87784C4.99053 2.2588 5.19324 2.75518 5.19324 3.36702C5.19324 3.92113 4.99633 4.38288 4.6025 4.7523C4.19711 5.13325 3.66428 5.32373 3.00405 5.32373H2.98668C2.3496 5.32373 1.83417 5.13325 1.44034 4.7523C1.04651 4.37135 0.849609 3.89227 0.849609 3.31507ZM1.07548 18.4666V6.89949H4.93262V18.4666H1.07548ZM7.06969 18.4666H10.9268V12.0077C10.9268 11.6037 10.9732 11.292 11.0658 11.0726C11.228 10.6801 11.4741 10.3482 11.8042 10.077C12.1344 9.80568 12.5484 9.67005 13.0465 9.67005C14.3438 9.67005 14.9925 10.5416 14.9925 12.2848V18.4666H18.8496V11.8345C18.8496 10.126 18.4442 8.83022 17.6334 7.9471C16.8226 7.06399 15.7512 6.62243 14.4191 6.62243C12.9249 6.62243 11.7608 7.26312 10.9268 8.54451V8.57914H10.9095L10.9268 8.54451V6.89949H7.06969C7.09285 7.26889 7.10444 8.41751 7.10444 10.3454C7.10444 12.2732 7.09285 14.9803 7.06969 18.4666Z"
                                        fill="#fff" />
                                </svg>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</template>
