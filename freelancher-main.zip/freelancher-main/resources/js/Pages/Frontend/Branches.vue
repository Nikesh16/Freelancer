<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
import Header from '@/Pages/Frontend/Header.vue';
import Footer from '@/Pages/Frontend/Footer.vue';
import CardBox from "@/Components/CardBox.vue";
import Sort from "@/Components/Admin/Sort.vue";
import Pagination from "@/Components/Admin/Pagination.vue"
import BaseButton from '@/Components/BaseButton.vue'
import { mdiChevronDown, mdiChevronUp } from '@mdi/js'

const props = defineProps({
    branches: {
        type: Object,
        default: {}
    },
});
const searchInput = ref('');
const expandedRows = ref({});

const filteredBranches = computed(() => {
    const searchTerm = searchInput.value.toLowerCase();
    return Object.values(props.branches).filter(item => {
        return item.branch_code.toLowerCase().includes(searchTerm)||item.area_coverage.toLowerCase().includes(searchTerm)||item.region.toLowerCase().includes(searchTerm) ;
    });
});

const toggleRow = (index) => {
    expandedRows.value[index] = !expandedRows.value[index];
};
</script>
<template>
    <div>
        <Header class="shadow-md" />
        <div class="min-h-[60vh]">
            <div class="container mt-4">
                <div class="flex justify-between items-center">
                    <div class="font-medium text-[20px]">Locations</div>
                    <div class="flex gap-2">
                        <div>
                            <button type="button"
                                class="flex items-center justify-center flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg focus:outline-none hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <svg class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                    stroke-width="2" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                                </svg>
                                <a :href="route('export_frontend_branch')" target="_blank">Export</a>
                            </button>
                        </div>
                        <input type="search" class="border border-gray-300 rounded-md" placeholder="Search branches"
                            v-model="searchInput" />
                    </div>

                </div>
            </div>
            <!-- {{ branches }} -->
            <CardBox class="mb-0 container mt-4" has-table>
                <table>
                    <thead>
                        <tr>
                            <th>
                                <Sort label="Branch Name" anknoFill />
                            </th>
                            <th>
                                <Sort label="Branch Code" anknoFill />
                            </th>
                            <th>
                                <Sort label="Muncipality" anknoFill />
                            </th>
                            <th>
                                <Sort label="District" anknoFill />
                            </th>
                            <th>
                                <Sort label="Region" anknoFill />
                            </th>
                            <!-- <th>
                                <Sort label="Address" anknoFill />
                            </th> -->
                            <!-- <th>
                                <Sort label="Phone" anknoFill />
                            </th>
                            <th>
                                <Sort label="Alt Phone Number" anknoFill />
                            </th>
                            <th>
                                <Sort label="Min.
                                Delivery Charges(1KG)" anknoFill />
                            </th>


                            <th>
                                <Sort label="Per KG increase Cost" anknoFill />
                            </th> -->
                        </tr>
                    </thead>

                    <tbody>
                        <template v-for="(branch, index) in filteredBranches" :key="branch.id">

                        <tr class="group relative">
                            <td data-label="Branch Name">
                                <BaseButton
                                    :icon="expandedRows[index] ? mdiChevronUp : mdiChevronDown"
                                    icon-w="w-4"
                                    icon-h="h-4"
                                    color="info"
                                    small
                                    class="hover:cursor-default"
                                    @click="toggleRow(index)"
                                />
                                &nbsp;
                                {{ branch.name ? branch.name : 'N/A' }}
                            </td>
                            <td data-label="Branch Code">
                                {{ branch.branch_code ? branch.branch_code : 'N/A' }}
                            </td>

                            <td data-label="Muncipality">
                                {{ branch.muncipality ? branch.muncipality : 'N/A' }}
                            </td>

                            <td data-label="District">
                                {{ branch.district ? branch.district : 'N/A' }}
                            </td>
                            <td data-label="Region">
                                {{ branch.region ? branch.region : 'N/A' }}
                            </td>
                            <!-- <td data-label="Address">
                                {{ branch.address ? branch.address : 'N/A' }}
                            </td>
                            <td data-label="Phone Number">
                                {{ branch.phone_number ? branch.phone_number : 'N/A' }}
                            </td>
                            <td data-label="Alt Phone Number">
                                {{ branch.alt_phone_number ? branch.alt_phone_number : 'N/A' }}
                            </td>
                            <td data-label="Min.
                                Delivery Charges(1KG)">
                               {{ branch.cod_fee ? branch.cod_fee : 'N/A' }}
                            </td>
                            <td data-label="Per KG increase Cost">
                                {{ branch.longitude ? branch.longitude : 'N/A' }}
                            </td> -->
                        </tr>
                        <tr class="expanded-content" v-if="expandedRows[index]">
                            <td colspan="6" data-label="Coverage Area">
                                <strong>Area Covered: &nbsp; </strong>
                                {{ branch.area_coverage ? branch.area_coverage : 'N/A' }}
                            </td>
                        </tr>
                        </template>
                    </tbody>
                </table>
            </CardBox>
        </div>
    </div>
    <div class="container">
        <Footer />
    </div>
</template>

<style scoped>
    .expanded-content {
        background-color: #f5f9f1;
        height: 50px;
    }
</style>
