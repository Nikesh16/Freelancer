<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import { ref } from "vue"
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import FormFilePicker from '@/Components/FormFilePicker.vue'
const props = defineProps({
    buttonText: {
        type: Object,
        default: 'Send'
    },
    isJobField: {
        type: Boolean,
        default: ''
    },
    isinputVisible: {
        type: Boolean,
        default: ''
    },
    isaTextChange: Boolean,
    isaVisible: Boolean,
    isheadVisible: Boolean,
    isRowDesign: Boolean,
    isColorDesign: Boolean,
})

const form = useForm({
    name: '',
    email: '',
    phone: '',
    image:'',
    job_category_id:'',
    request_category: 'Choose Your Request',
    description: ''
})

const requestOptions = ['Option1', 'Option2', 'Option3'];
</script>
<template>
    <div>
        <div>
            <!-- {{ isJobField }} -->
            <div class="header">
                <h3 class="text-[40px] font-bold text-gray-900 text-center leading-[48px] pt-[24px]"
                    v-if="!isheadVisible">
                    Submit a Request
                </h3>
                <h4 class="text-base mt-[16px] text-center" v-if="isaVisible">
                    Feel free to contact us via the form below:
                </h4>
            </div>
            <CardBox form @submit.prevent="form.post(route('FeedbackSubmitRequest'))" ankcustomClass>
                <div :class="isRowDesign ? 'grid lg:grid-cols-3 grid-cols-1 lg:gap-6 ' : ''">
                    <FormField :class="{ 'text-red-400': form.errors.name }">
                        <FormControl v-model="form.name" type="text" placeholder="Your Name" :error="form.errors.name">
                            <div class="text-red-400 text-sm" v-if="form.errors.name">
                                {{ form.errors.name }}
                            </div>
                        </FormControl>
                    </FormField>
                    <FormField :class="{ 'text-red-400': form.errors.email }">
                        <FormControl v-model="form.email" type="email" placeholder="Your Email"
                            :error="form.errors.email">
                            <div class="text-red-400 text-sm" v-if="form.errors.email">
                                {{ form.errors.email }}
                            </div>
                        </FormControl>
                    </FormField>
                    <FormField :class="{ 'text-red-400': form.errors.phone }">
                        <FormControl v-model="form.phone" type="number" placeholder="Your Phone"
                            :error="form.errors.phone">
                            <div class="text-red-400 text-sm" v-if="form.errors.phone">
                                {{ form.errors.phone }}
                            </div>
                        </FormControl>
                    </FormField>
                </div>
                <FormControl :class="isRowDesign ? '' : 'mt-6'" v-if="!isinputVisible" class="text-sm mb-6"
                    v-model="form.request_category" :options="requestOptions">
                    <div class="text-red-400 text-sm" v-if="form.errors.request_category"
                        placeholder="Choose Your Request">
                        {{ form.errors.request_category }}
                    </div>
                </FormControl>
                <div :class="isRowDesign ? 'lg:mt-2 mt-8' : 'mt-6'">
                    <FormField :class="{ 'text-red-400 text-sm ': form.errors.description }">
                        <FormControl ankcstmclass v-model="form.description" type="text" placeholder="Your Message"
                            :error="form.errors.description">
                            <div class="text-red-400 text-sm" v-if="form.errors.description">
                                {{ form.errors.description }}
                            </div>
                        </FormControl>
                    </FormField>
                </div>
                <!-- <FormField class="mt-3" label="Image" :class="{ 'text-red-400': form.errors.image }">
                    <FormFilePicker placeholder="Image" v-model="form.image" :error="form.errors.image" type="file" />
                    <div class="text-red-400 text-sm" v-if="form.errors.image">
                        {{ form.errors.image }}
                    </div>
                </FormField> -->
                <div :class="isColorDesign ? 'flex justify-center' : ''">
                    <button
                        :class="isRowDesign ? 'mt-6' : 'mt-6', isColorDesign ? 'bg-secondary hover:!bg-white hover:text-black border-none max-w-max' : ''"
                        class="py-[8px] px-[20px] mb-[20px]  bg-primary hover:bg-secondary border-2 w-full duration-500 text-white rounded-[8px]">
                        <span>{{ props.buttonText }}</span>
                    </button>
                </div>



            </CardBox>
        </div>
    </div>
</template>
