<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import { ref } from "vue"
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import NotificationBar from "@/Components/NotificationBar.vue"
const form = useForm({
    phone: '',
    type: '',
})
const props = defineProps({
    property: {
        type: Object,
        default: 'Send'
    },
    type_value: {
        type: Object,
        default: ''
    },
})

const termsData = ref('');

</script>
<template>
    <div>
        <NotificationBar :key="Date.now()" v-if="$page.props.flash.message" color="success" :icon="mdiAlertBoxOutline">
            {{ $page.props.flash.message }}
        </NotificationBar>

        <!-- {{  type_value }} -->
        <div class="bg-agray py-[30px] px-[20px] rounded-[10px]">
            <h2 class="font-bold sm:text-[32px] sm:leading-[41.6px] text-[24px] leading-[33.6px] text-center">
                Like This Case?</h2>
            <h4 class="text-textblack text-center mt-[10px]">Lorem ipsum dolor sit amet, consectetur
                adipiscing elit. </h4>
            <CardBox form @submit.prevent="form.post(route('FeedbackCaseRequest', [property.slug, type_value]))"
                ankcustomClass>
                <div>
                    <FormField :class="{ 'text-red-400': form.errors.phone }">
                        <FormControl v-model="form.phone" type="number" placeholder="Your Phone"
                            :error="form.errors.phone">
                            <div class="text-red-400 text-sm" v-if="form.errors.phone">
                                {{ form.errors.phone }}
                            </div>
                        </FormControl>
                    </FormField>
                </div>
                <div class="flex items-center gap-1 mt-[24px]">
                    <input type="checkbox" v-model="termsData"
                        class="w-6 h-6 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 ">
                    <label for="checkbox-item-2"
                        class="w-full ms-2 text-[14px] font-medium text-gray-900 rounded dark:text-gray-300">I
                        accept the
                        <span class="underline cursor-pointer" data-modal-target="default-modal"
                            data-hs-overlay="#hs-vertically-centered-modal-terms"> Terms </span>

                        <!-- Main modal -->
                        <div id="hs-vertically-centered-modal-terms" tabindex="-1" aria-hidden="true"
                            class="hs-overlay hs-overlay-open:bg-black backdrop-blur-sm bg-opacity-50 w-full hidden size-full fixed top-0 start-0 z-[80] overflow-x-hidden overflow-y-auto pointer-events-none">
                            <div
                                class="hs-overlay-open:mt-7  hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all  md:max-w-[600px] max-h-full m-3 md:mx-auto mx-2 h-[calc(100%-3.5rem)] min-h-[calc(100%-3.5rem)] flex items-center">
                                <div
                                    class="w-full max-h-full overflow-hidden flex flex-col bg-white border shadow-sm rounded-xl pointer-events-auto dark:bg-neutral-800 dark:border-neutral-700 dark:shadow-neutral-700/70">
                                    <div class="flex justify-between items-center  px-4  dark:border-neutral-700">
                                        <button type="button"
                                            class="text-gray-400  mt-[10px] bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm ms-auto inline-flex justify-center items-center"
                                            data-hs-overlay="#hs-vertically-centered-modal-terms">
                                            <span class="sr-only">Close</span>
                                            <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_500_14801)">
                                                    <path
                                                        d="M20.0002 17.6436L28.2502 9.39355L30.6069 11.7502L22.3569 20.0002L30.6069 28.2502L28.2502 30.6069L20.0002 22.3569L11.7502 30.6069L9.39355 28.2502L17.6436 20.0002L9.39355 11.7502L11.7502 9.39355L20.0002 17.6436Z"
                                                        fill="#94A4C1" />
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_500_14801">
                                                        <rect width="40" height="40" fill="white" />
                                                    </clipPath>
                                                </defs>
                                            </svg>
                                        </button>
                                    </div>
                                    <div class="header">
                                        <h3
                                            class="text-[40px] font-bold text-gray-900 text-center leading-[48px] pt-[24px]">
                                            Terms of Service
                                        </h3>
                                    </div>
                                    <!-- Modal body -->
                                    <div class="p-4 md:p-5 space-y-4">
                                        <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                                            With less than a month to go before the European Union
                                            enacts new consumer privacy laws for its citizens, companies
                                            around the world are updating their terms of service
                                            agreements to comply.
                                        </p>
                                        <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                                            The European Union’s General Data Protection Regulation
                                            (G.D.P.R.) goes into effect on May 25 and is meant to ensure
                                            a common set of data rights in the European Union. It
                                            requires organizations to notify users as soon as possible
                                            of high-risk data breaches that could personally affect
                                            them.
                                        </p>
                                    </div>
                                    <!-- Modal footer -->
                                    <div
                                        class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                                        <button data-modal-hide="default-modal" @click="termsData = true"
                                            class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">I
                                            accept</button>
                                        <button data-modal-hide="default-modal" type="button"
                                            class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Decline</button>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </label>
                </div>
                <!-- {{ termsData }} -->
                <button :disabled="termsData == 'false'"
                    :class="termsData == false ? 'opacity-50 cursor-not-allowed' : ''"
                    class="py-[8px] px-[20px] mt-[24px]  bg-primary hover:bg-secondary border-2 w-full duration-500 text-white rounded-[8px]">
                    <span>Submit a Request</span>
                </button>
            </CardBox>

        </div>
    </div>
</template>
