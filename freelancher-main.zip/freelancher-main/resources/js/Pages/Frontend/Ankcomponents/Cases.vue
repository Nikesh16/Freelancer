<script setup>
import { Head, Link, useForm, usePage } from "@inertiajs/vue3"
import { computed, ref } from "vue"
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const modules = ref([Autoplay, Pagination, Navigation]);

const page = usePage()

const property_space = computed(() => page.props.property_space.property_data);
const props = defineProps({
    spacesText: {
        type: Object,
        default: 'Our Cases'
    },
    cases: {
        type: Object,
        default: ''
    },
    spacesdespText: {
        type: Object,
        default: 'We elevate the guest experience by incorporating thoughtful design & living brands into our apartments'
    },

    isDespVisible: Boolean,
})
</script>
<template>
    <div>
        <div class="room   lg:p-[64px] p-[20px] bg-agray">
            <div class="container">
                <div class="title flex sm:flex-row flex-col justify-between   gap-2  sm:items-center">
                    <div>
                        <h2 class="lg:text-[40px] text-[32px] lg:leading-[48px] leading-[38.4px]  font-bold">
                            {{ spacesText }}
                        </h2>
                        <h4 v-if="isDespVisible" class="lg:text-[16px] lg:leading-[24px] text-customblack mt-[20px]">{{
                            spacesdespText }}</h4>
                    </div>
                    <div class="bottom-title-group flex-shrink-0">
                        <Link :href="route('allRoom')">
                        <button
                            class="py-[8px] px-[20px] max-w-max border-primary hover:bg-primary border-2 text-black duration-500 hover:text-white rounded-[8px]">
                            View all
                        </button>
                        </Link>

                    </div>
                </div>
                <div>
                    <div class="team mt-[24px]">
                        <div>

                            <div>
                                <swiper :spaceBetween="10" :navigation="true" :slidesPerView="1" :pagination="true"
                                    :loop="true" :autoplay="{
                                        delay: 5000,

                                        disableOnInteraction: false,
                                        pauseOnMouseEnter: true,
                                    }" :modules="modules" :breakpoints="{
                                    '640': {
                                        slidesPerView: 2,
                                        spaceBetween: 10,
                                    },
                                    '768': {
                                        slidesPerView: 3,
                                        spaceBetween: 10,
                                    },
                                    '1024': {
                                        slidesPerView: 3,
                                        spaceBetween: 10,
                                    },
                                }">
                                    <swiper-slide v-for="property_data in cases">
                                        <Link :href="route('caseDetails',property_data.slug)">
                                        <div class="chil">
                                            <div class="features-child-wrap flex flex-col  relative">
                                                <div class="comming-soon-batch mb-[10px] absolute top-4 right-4" >
                                                    <div class="wrap bg-primary text-white px-2 text-base font-bold py-1 max-w-max rounded-[4px]">
                                                        <span>monthly rate + {{ property_data.increment_percentage }}</span>
                                                    </div>
                                                </div>
                                                <img :src="'/storage/' + property_data.image"
                                                    class="object-cover aspect-square h-[250px] w-full duration-500 rounded-[10px]"
                                                    alt="">
                                                <h3 class="mt-[20px] font-bold text-xl">{{ property_data.name }}</h3>
                                                <h4 class="mt-4 text-base text-textcolor">Full Renovation
                                                </h4>
                                                <div
                                                    class="roomamnety flex gap-[20px] flex-wrap items-center mt-[20px]">
                                                    <div class="child flex gap-[10px] items-center">
                                                        <div>
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <g clip-path="url(#clip0_724_622)">
                                                                    <path
                                                                        d="M12 0C5.37256 0 0 5.37256 0 12C0 18.6274 5.37256 24 12 24C18.6274 24 24 18.6274 24 12C23.9923 5.37576 18.6242 0.00769355 12 0ZM12 23.2258C5.80016 23.2258 0.774194 18.1998 0.774194 12C0.774194 5.80016 5.80016 0.774194 12 0.774194C18.1998 0.774194 23.2258 5.80016 23.2258 12C23.219 18.197 18.197 23.219 12 23.2258Z"
                                                                        fill="#201F23" />
                                                                    <path
                                                                        d="M12.3875 11.8398V3.4839C12.3875 3.38123 12.3467 3.28277 12.2741 3.21018C12.2015 3.13759 12.103 3.0968 12.0004 3.0968C11.8977 3.0968 11.7993 3.13759 11.7267 3.21018C11.6541 3.28277 11.6133 3.38123 11.6133 3.4839V12C11.6133 12.1027 11.6541 12.2011 11.7267 12.2737L15.2106 15.7576C15.2844 15.8289 15.3836 15.868 15.4862 15.8662C15.5889 15.8644 15.6866 15.8219 15.7579 15.7481C15.8276 15.6759 15.8666 15.5795 15.8666 15.4792C15.8666 15.3788 15.8276 15.2824 15.7579 15.2102L12.3875 11.8398Z"
                                                                        fill="#201F23" />
                                                                    <path
                                                                        d="M11.9985 1.5484C6.2262 1.5484 1.54688 6.22772 1.54688 12C1.54688 17.7723 6.2262 22.4516 11.9985 22.4516C17.7708 22.4516 22.4501 17.7723 22.4501 12C22.4437 6.23038 17.7681 1.55479 11.9985 1.5484ZM11.9985 21.6774C6.65379 21.6774 2.32107 17.3447 2.32107 12C2.32107 6.65532 6.65379 2.32259 11.9985 2.32259C17.3432 2.32259 21.6759 6.65532 21.6759 12C21.67 17.3422 17.3407 21.6715 11.9985 21.6774Z"
                                                                        fill="#201F23" />
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_724_622">
                                                                        <rect width="24" height="24" fill="white" />
                                                                    </clipPath>
                                                                </defs>
                                                            </svg>

                                                        </div>
                                                        <div>
                                                            {{ property_data.duration }} Months
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="pricing bg-secondary text-white rounded-[8px] max-w-max mt-[20px] p-[8px]">
                                                    <span class="uppercase font-bold">from {{ property_data.total_budget }}
                                                        AED</span>
                                                </div>
                                            </div>
                                        </div>
                                        </Link>

                                    </swiper-slide>

                                </swiper>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
.swiper {
    padding-top: 50px;
    padding-bottom: 100px;
}

.swiper-wrapper {
    position: relative;
}

.swiper-button-next,
.swiper-button-prev {
    position: absolute;
    padding: 10px;
    top: 95%;
    border: .3px solid #707070;
    width: 40px;
    height: 40px;
    border-radius: 100%;
    /* background: #062744; */
    /* opacity: 0.2; */
    transition: all .3s;
}

.swiper-button-prev {
    position: absolute;
    padding: 10px;
    left: calc(100% - 105px);
}

.swiper-button-prev::after {
    font-size: 24px;
    font-weight: bold;
    color: #707070;
}

.swiper-button-next::after {
    font-size: 24px;
    font-weight: bold;
    color: #707070;
}

.swiper-pagination-bullets,
.swiper-pagination-bullets.swiper-pagination-horizontal {
    width: auto !important;
}

.swiper-pagination-bullet:not(.swiper-pagination-bullet-active):not(.swiper-button-prev):not(.swiper-button-next) {
    /* display: none; */
}
</style>
