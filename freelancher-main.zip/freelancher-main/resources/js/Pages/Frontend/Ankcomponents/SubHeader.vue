<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import { ref } from "vue"
const props = defineProps({
    headTitle: {
        type: Object,
        default: 'Title'
    },
    subHeadTitle: {
        type: Object,
        default: 'SubTitle'
    },
    isaTextChange: Boolean,
    isaVisible: Boolean,
    isheadVisible: Boolean,
    isinputVisible: Boolean,
    isRowDesign: Boolean,
    isHome: Boolean,
    isAllData: Boolean
})
</script>
<template>
    <div>
        <div>
            <div class="header-top">
                <div class="header-top-wrap h-[556px] relative w-full flex justify-center items-center">
                    <div class="absolute left-0 top-0 w-full h-full">
                        <img src="/images/propertyaudit.png" class="w-full h-full object-cover" alt="">
                    </div>
                    <div class="absolute w-full h-full bg-black bg-opacity-60">

                    </div>
                    <div class="title z-[1] text-white">
                        <div class="title flex justify-center flex-col items-center">
                            <h2
                                class="md:text-[56px] text-[36px] md:leading-[67.2px] leading-[43.2px] text-center font-bold">
                                {{ headTitle }}
                            </h2>
                            <h3 class="text-base mt-[16px] text-center">
                                {{ subHeadTitle }}
                            </h3>
                            <button v-if="!isHome" data-hs-overlay="#hs-vertically-centered-modal"
                                class="py-[8px] px-[20px] mt-[50px] bg-primary hover:bg-secondary duration-500 text-white rounded-[8px]">
                                Submit a Request
                            </button>

                            <div v-if="isHome" class="button-group flex items-center gap-2 mt-[50px]">
                                <button
                                    class="py-[8px] px-[20px] sm:min-w-[200px] bg-primary hover:bg-white hover:text-textcolor duration-500 text-white rounded-[8px]">
                                    Get a Free Consultation
                                </button>
                                <Link :href="route('allRoom')">
                                <button
                                    class="py-[8px] px-[20px] sm:min-w-[200px] hover:bg-primary bg-secondary duration-500 text-white rounded-[8px]">
                                    Our Cases
                                </button>
                            </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
