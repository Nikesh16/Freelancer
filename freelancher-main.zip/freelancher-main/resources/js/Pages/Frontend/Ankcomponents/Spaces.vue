<script setup>
import { Head, Link, useForm, usePage } from "@inertiajs/vue3"
import { computed, ref } from "vue"
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const modules = ref([Autoplay, Pagination, Navigation]);

const page = usePage()

const property_space = computed(() => page.props.property_space.property_data);
const props = defineProps({
    spacesText: {
        type: Object,
        default: 'Our Spaces'
    },
    spacesdespText: {
        type: Object,
        default: 'We elevate the guest experience by incorporating thoughtful design & living brands into our apartments'
    },
    isDespVisible: Boolean,
})
</script>
<template>
    <div>
        <div class="room   lg:p-[64px] p-[20px] bg-agray">
            <div class="container">
                <div class="title flex sm:flex-row flex-col justify-between   gap-2  sm:items-center">
                    <div>
                        <h2 class="lg:text-[40px] text-[32px] lg:leading-[48px] leading-[38.4px]  font-bold">
                            {{ spacesText }}
                        </h2>
                        <h4 v-if="isDespVisible" class="lg:text-[16px] lg:leading-[24px] text-customblack mt-[20px]">{{
                            spacesdespText }}</h4>
                    </div>
                    <div class="bottom-title-group flex-shrink-0">
                        <Link :href="route('allRoom')">
                        <button
                            class="py-[8px] px-[20px] max-w-max border-primary hover:bg-primary border-2 text-black duration-500 hover:text-white rounded-[8px]">
                            View all
                        </button>
                        </Link>

                    </div>
                </div>
                <div>
                    <div class="team mt-[24px]">
                        <div>

                            <div>
                                <swiper :spaceBetween="10" :navigation="true" :slidesPerView="1" :pagination="true" :loop="true" :autoplay="{
                                    delay: 5000,

                                    disableOnInteraction: false,
                                    pauseOnMouseEnter: true,
                                }" :modules="modules" :breakpoints="{
                                    '640': {
                                        slidesPerView: 2,
                                        spaceBetween: 10,
                                    },
                                    '768': {
                                        slidesPerView: 3,
                                        spaceBetween: 10,
                                    },
                                    '1024': {
                                        slidesPerView: 3,
                                        spaceBetween: 10,
                                    },
                                }">
                                    <swiper-slide v-for="property_data in property_space">
                                        <Link :href="route('roomDetails')">
                                        <div class="chil">
                                            <div class="features-child-wrap flex flex-col  relative">
                                                <img :src="'/storage/' + property_data.image"
                                                    class="object-cover aspect-square h-[250px] w-full duration-500 rounded-[10px]"
                                                    alt="">
                                                <h3 class="mt-[20px] font-bold text-xl">{{ property_data.name }}</h3>
                                                <h4 class="mt-4 text-base text-textcolor">{{ property_data.location }}
                                                </h4>
                                                <div
                                                    class="roomamnety flex gap-[20px] flex-wrap items-center mt-[20px]">
                                                    <div class="child flex gap-[10px] items-center">
                                                        <div>
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    d="M23.25 16.125H22.875V13.125C22.8745 12.7273 22.7163 12.3461 22.4351 12.0649C22.1539 11.7837 21.7727 11.6255 21.375 11.625V5.25C21.3745 4.85234 21.2163 4.47111 20.9351 4.18992C20.6539 3.90872 20.2727 3.75052 19.875 3.75H4.125C3.72734 3.75052 3.34611 3.90872 3.06492 4.18992C2.78372 4.47111 2.62552 4.85234 2.625 5.25V11.625C2.22734 11.6255 1.84611 11.7837 1.56492 12.0649C1.28372 12.3461 1.12552 12.7273 1.125 13.125V16.125H0.75C0.650544 16.125 0.555161 16.1645 0.484835 16.2348C0.414509 16.3052 0.375 16.4005 0.375 16.5V18C0.375 18.0995 0.414509 18.1948 0.484835 18.2652C0.555161 18.3355 0.650544 18.375 0.75 18.375H1.125V19.875C1.125 19.9745 1.16451 20.0698 1.23483 20.1402C1.30516 20.2105 1.40054 20.25 1.5 20.25H2.625C2.71167 20.25 2.79567 20.22 2.86269 20.1651C2.9297 20.1101 2.97558 20.0336 2.9925 19.9486L3.3075 18.375H20.6925L21.0075 19.9486C21.0244 20.0336 21.0703 20.1101 21.1373 20.1651C21.2043 20.22 21.2883 20.25 21.375 20.25H22.5C22.5995 20.25 22.6948 20.2105 22.7652 20.1402C22.8355 20.0698 22.875 19.9745 22.875 19.875V18.375H23.25C23.3495 18.375 23.4448 18.3355 23.5152 18.2652C23.5855 18.1948 23.625 18.0995 23.625 18V16.5C23.625 16.4005 23.5855 16.3052 23.5152 16.2348C23.4448 16.1645 23.3495 16.125 23.25 16.125ZM3.375 5.25C3.37526 5.05117 3.45436 4.86055 3.59496 4.71996C3.73555 4.57936 3.92617 4.50026 4.125 4.5H19.875C20.0738 4.50026 20.2644 4.57936 20.405 4.71996C20.5456 4.86055 20.6247 5.05117 20.625 5.25V11.625H19.875V10.125C19.8745 9.72733 19.7163 9.34611 19.4351 9.06492C19.1539 8.78372 18.7727 8.62552 18.375 8.625H13.875C13.4773 8.62552 13.0961 8.78372 12.8149 9.06492C12.5337 9.34611 12.3755 9.72733 12.375 10.125V11.625H11.625V10.125C11.6245 9.72733 11.4663 9.34611 11.1851 9.06492C10.9039 8.78372 10.5227 8.62552 10.125 8.625H5.625C5.22733 8.62552 4.84611 8.78372 4.56492 9.06492C4.28372 9.34611 4.12552 9.72733 4.125 10.125V11.625H3.375V5.25ZM19.125 10.125V11.625H13.125V10.125C13.1253 9.92617 13.2044 9.73555 13.345 9.59496C13.4856 9.45436 13.6762 9.37526 13.875 9.375H18.375C18.5738 9.37526 18.7644 9.45436 18.905 9.59496C19.0456 9.73555 19.1247 9.92617 19.125 10.125ZM10.875 10.125V11.625H4.875V10.125C4.87526 9.92617 4.95436 9.73555 5.09496 9.59496C5.23555 9.45436 5.42617 9.37526 5.625 9.375H10.125C10.3238 9.37526 10.5144 9.45436 10.655 9.59496C10.7956 9.73555 10.8747 9.92617 10.875 10.125ZM1.875 13.125C1.87526 12.9262 1.95436 12.7356 2.09496 12.595C2.23555 12.4544 2.42617 12.3753 2.625 12.375H21.375C21.5738 12.3753 21.7644 12.4544 21.905 12.595C22.0456 12.7356 22.1247 12.9262 22.125 13.125V16.125H1.875V13.125ZM2.3175 19.5H1.875V18.375H2.5425L2.3175 19.5ZM22.125 19.5H21.6825L21.4575 18.375H22.125V19.5ZM22.875 17.625H1.125V16.875H22.875V17.625Z"
                                                                    fill="black" />
                                                            </svg>
                                                        </div>
                                                        <div>
                                                            {{ property_data.bed_room }} bedroom
                                                        </div>
                                                    </div>
                                                    <div class="child flex gap-[10px] items-center">
                                                        <div>
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    d="M23.25 13.125H21.375V5.25C21.375 4.25544 20.9799 3.30161 20.2766 2.59835C19.5734 1.89509 18.6196 1.5 17.625 1.5C16.6304 1.5 15.6766 1.89509 14.9733 2.59835C14.2701 3.30161 13.875 4.25544 13.875 5.25V5.28188C13.3511 5.37109 12.8755 5.64263 12.5324 6.04853C12.1893 6.45442 12.0007 6.96852 12 7.5V8.625C12 8.72446 12.0395 8.81984 12.1098 8.89017C12.1802 8.96049 12.2755 9 12.375 9H16.125C16.2245 9 16.3198 8.96049 16.3902 8.89017C16.4605 8.81984 16.5 8.72446 16.5 8.625V7.5C16.4993 6.96852 16.3107 6.45442 15.9676 6.04853C15.6245 5.64263 15.1489 5.37109 14.625 5.28188V5.25C14.625 4.45435 14.9411 3.69129 15.5037 3.12868C16.0663 2.56607 16.8294 2.25 17.625 2.25C18.4206 2.25 19.1837 2.56607 19.7463 3.12868C20.3089 3.69129 20.625 4.45435 20.625 5.25V13.125H0.75C0.650544 13.125 0.555161 13.1645 0.484835 13.2348C0.414509 13.3052 0.375 13.4005 0.375 13.5V14.625C0.375 14.7245 0.414509 14.8198 0.484835 14.8902C0.555161 14.9605 0.650544 15 0.75 15H1.5V18.375C1.5009 19.0059 1.72868 19.6155 2.14175 20.0925C2.55483 20.5694 3.12565 20.8818 3.75 20.9728V22.125C3.75 22.2245 3.78951 22.3198 3.85984 22.3902C3.93016 22.4605 4.02554 22.5 4.125 22.5H5.625C5.72446 22.5 5.81984 22.4605 5.89016 22.3902C5.96049 22.3198 6 22.2245 6 22.125V21H18V22.125C18 22.2245 18.0395 22.3198 18.1098 22.3902C18.1802 22.4605 18.2755 22.5 18.375 22.5H19.875C19.9745 22.5 20.0698 22.4605 20.1402 22.3902C20.2105 22.3198 20.25 22.2245 20.25 22.125V20.9728C20.8744 20.8818 21.4452 20.5694 21.8582 20.0925C22.2713 19.6155 22.4991 19.0059 22.5 18.375V15H23.25C23.3495 15 23.4448 14.9605 23.5152 14.8902C23.5855 14.8198 23.625 14.7245 23.625 14.625V13.5C23.625 13.4005 23.5855 13.3052 23.5152 13.2348C23.4448 13.1645 23.3495 13.125 23.25 13.125ZM15.75 8.25H12.75V7.875H15.75V8.25ZM15.7027 7.125H12.7973C12.8806 6.803 13.0684 6.51778 13.3313 6.31414C13.5943 6.11051 13.9174 6.00001 14.25 6.00001C14.5826 6.00001 14.9057 6.11051 15.1687 6.31414C15.4316 6.51778 15.6194 6.803 15.7027 7.125ZM5.25 21.75H4.5V21H5.25V21.75ZM19.5 21.75H18.75V21H19.5V21.75ZM21.75 18.375C21.7495 18.8721 21.5518 19.3488 21.2003 19.7003C20.8488 20.0518 20.3721 20.2495 19.875 20.25H4.125C3.62787 20.2495 3.15125 20.0518 2.79972 19.7003C2.4482 19.3488 2.2505 18.8721 2.25 18.375V15H21.75V18.375ZM22.875 14.25H1.125V13.875H22.875V14.25Z"
                                                                    fill="black" />
                                                                <path
                                                                    d="M14.25 11.25C14.3495 11.25 14.4448 11.2105 14.5152 11.1402C14.5855 11.0698 14.625 10.9745 14.625 10.875V9.75C14.625 9.65054 14.5855 9.55516 14.5152 9.48483C14.4448 9.41451 14.3495 9.375 14.25 9.375C14.1505 9.375 14.0552 9.41451 13.9848 9.48483C13.9145 9.55516 13.875 9.65054 13.875 9.75V10.875C13.875 10.9745 13.9145 11.0698 13.9848 11.1402C14.0552 11.2105 14.1505 11.25 14.25 11.25ZM13.875 12.375C13.875 12.4745 13.9145 12.5698 13.9848 12.6402C14.0552 12.7105 14.1505 12.75 14.25 12.75C14.3495 12.75 14.4448 12.7105 14.5152 12.6402C14.5855 12.5698 14.625 12.4745 14.625 12.375V12C14.625 11.9005 14.5855 11.8052 14.5152 11.7348C14.4448 11.6645 14.3495 11.625 14.25 11.625C14.1505 11.625 14.0552 11.6645 13.9848 11.7348C13.9145 11.8052 13.875 11.9005 13.875 12V12.375ZM16.125 11.25V9.75C16.125 9.65054 16.0855 9.55516 16.0152 9.48483C15.9448 9.41451 15.8495 9.375 15.75 9.375C15.6505 9.375 15.5552 9.41451 15.4848 9.48483C15.4145 9.55516 15.375 9.65054 15.375 9.75V11.25C15.375 11.3495 15.4145 11.4448 15.4848 11.5152C15.5552 11.5855 15.6505 11.625 15.75 11.625C15.8495 11.625 15.9448 11.5855 16.0152 11.5152C16.0855 11.4448 16.125 11.3495 16.125 11.25ZM13.125 10.5V10.125C13.125 10.0255 13.0855 9.93016 13.0152 9.85983C12.9448 9.78951 12.8495 9.75 12.75 9.75C12.6505 9.75 12.5552 9.78951 12.4848 9.85983C12.4145 9.93016 12.375 10.0255 12.375 10.125V10.5C12.375 10.5995 12.4145 10.6948 12.4848 10.7652C12.5552 10.8355 12.6505 10.875 12.75 10.875C12.8495 10.875 12.9448 10.8355 13.0152 10.7652C13.0855 10.6948 13.125 10.5995 13.125 10.5Z"
                                                                    fill="black" />
                                                            </svg>

                                                        </div>
                                                        <div>
                                                            {{ property_data.bath_room }} bethroom
                                                        </div>
                                                    </div>
                                                    <div class="child flex gap-[10px] items-center">
                                                        <div>
                                                            {{ property_data.size }} sqm
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="pricing bg-secondary text-white rounded-[8px] max-w-max mt-[20px] p-[8px]">
                                                    <span class="uppercase font-bold">from {{ property_data.price }} M
                                                        AED/$</span>
                                                </div>
                                            </div>
                                        </div>
                                        </Link>

                                    </swiper-slide>

                                </swiper>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
.swiper{
padding-top: 50px;
padding-bottom: 100px;
}
.swiper-wrapper{
    position: relative;
}
.swiper-button-next,
.swiper-button-prev {
    position: absolute;
    padding: 10px;
    top: 95%;
    border: .3px solid #707070;
    width: 40px;
    height: 40px;
    border-radius: 100%;
    /* background: #062744; */
    /* opacity: 0.2; */
    transition: all .3s;
}

.swiper-button-prev{
    position: absolute;
    padding: 10px;
    left: calc(100% - 105px);
}

.swiper-button-prev::after {
    font-size: 24px;
    font-weight: bold;
    color: #707070;
}
.swiper-button-next::after {
    font-size: 24px;
    font-weight: bold;
    color: #707070;
}

.swiper-pagination-bullets, .swiper-pagination-bullets.swiper-pagination-horizontal {
    width: auto !important;
}

.swiper-pagination-bullet:not(.swiper-pagination-bullet-active):not(.swiper-button-prev):not(.swiper-button-next) {
    /* display: none; */
}
</style>
