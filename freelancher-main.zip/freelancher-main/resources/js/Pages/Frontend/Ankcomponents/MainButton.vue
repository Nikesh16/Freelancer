<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import { ref } from "vue"
const props = defineProps({
    headTitle: {
        type: Object,
        default: ''
    },
    isquestion:Boolean,
})
</script>
<template>
    <div>
        <div>
            <div v-if="isquestion" class="child rounded-[15px] py-2 px-2 border">
                <div class="flex gap-[10px] items-center">
                    <div>
                        <svg class="w-[100px] h-[100px]" height="111" viewBox="0 0 111 111" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g filter="url(#filter0_d_1_981)">
                                <rect x="20.1738" y="16.355" width="70" height="70" rx="15" fill="white" />
                            </g>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M52.4483 31.995L47.2762 41.7471C47.2174 41.8605 47.1313 41.9571 47.0284 42.0327C46.9255 42.1083 46.8058 42.1587 46.6798 42.1797L35.8063 44.0865C34.6808 44.2839 33.7568 45.086 33.404 46.1717C33.0512 47.2574 33.3263 48.4501 34.1222 49.2712L41.7995 57.2048C41.8877 57.2972 41.9549 57.4085 41.9948 57.5282C42.0347 57.6499 42.0452 57.778 42.0284 57.9061L40.4808 68.8363C40.3212 69.9661 40.7979 71.0937 41.7218 71.7657C42.6458 72.4377 43.8638 72.5427 44.8907 72.0408L54.8065 67.19C54.922 67.1333 55.048 67.106 55.1761 67.106V30.355C54.0317 30.355 52.9838 30.9871 52.4483 31.995Z"
                                fill="#FF8D3A" />
                            <path opacity="0.35" fill-rule="evenodd" clip-rule="evenodd"
                                d="M68.5485 57.2027L76.2259 49.2691C77.0196 48.448 77.2968 47.2553 76.9441 46.1696C76.5913 45.0839 75.6673 44.2818 74.5417 44.0844L63.6683 42.1797C63.5423 42.1566 63.4226 42.1062 63.3197 42.0327C63.2168 41.9571 63.1307 41.8605 63.0719 41.7471L57.8997 31.9929C57.3642 30.9871 56.3164 30.355 55.174 30.355V67.1039C55.3021 67.1039 55.4281 67.1333 55.5436 67.1879L65.4595 72.0387C66.4864 72.5406 67.7043 72.4335 68.6283 71.7636C69.5523 71.0916 70.029 69.9661 69.8694 68.8342L68.3217 57.904C68.3028 57.778 68.3154 57.6479 68.3553 57.5261C68.3931 57.4064 68.4603 57.2951 68.5485 57.2027Z"
                                fill="#FF8D3A" />
                            <defs>
                                <filter id="filter0_d_1_981" x="0.173828" y="0.35498" width="110" height="110"
                                    filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                    <feColorMatrix in="SourceAlpha" type="matrix"
                                        values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                                    <feOffset dy="4" />
                                    <feGaussianBlur stdDeviation="10" />
                                    <feColorMatrix type="matrix"
                                        values="0 0 0 0 0.090196 0 0 0 0 0.0588235 0 0 0 0 0.286275 0 0 0 0.08 0" />
                                    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1_981" />
                                    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1_981"
                                        result="shape" />
                                </filter>
                            </defs>
                        </svg>
                    </div>
                    <div class="flex gap- flex-col">
                        <div class="font-bold"> {{ headTitle }} </div>
                        <div class="flex items-center gap-2 mb-0">
                            <span> Browse all </span>
                            <span>
                                <svg class="w-[13px] h-[13px]" viewBox="0 0 13 15" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6.81116 4.12012L11.8112 9.12012L6.81116 14.1201" stroke="#6F6C90"
                                        stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M11.811 9.11963L1.17383 9.11963" stroke="#6F6C90" stroke-width="1.6"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <Link v-else>
                <div class="child rounded-[15px] py-2 px-2 bg-agray">
                    <div class="flex gap-[10px] items-center">
                        <div>
                            <svg class="w-[100px] h-[100px]" height="111" viewBox="0 0 111 111" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g filter="url(#filter0_d_1_981)">
                                    <rect x="20.1738" y="16.355" width="70" height="70" rx="15" fill="white" />
                                </g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M52.4483 31.995L47.2762 41.7471C47.2174 41.8605 47.1313 41.9571 47.0284 42.0327C46.9255 42.1083 46.8058 42.1587 46.6798 42.1797L35.8063 44.0865C34.6808 44.2839 33.7568 45.086 33.404 46.1717C33.0512 47.2574 33.3263 48.4501 34.1222 49.2712L41.7995 57.2048C41.8877 57.2972 41.9549 57.4085 41.9948 57.5282C42.0347 57.6499 42.0452 57.778 42.0284 57.9061L40.4808 68.8363C40.3212 69.9661 40.7979 71.0937 41.7218 71.7657C42.6458 72.4377 43.8638 72.5427 44.8907 72.0408L54.8065 67.19C54.922 67.1333 55.048 67.106 55.1761 67.106V30.355C54.0317 30.355 52.9838 30.9871 52.4483 31.995Z"
                                    fill="#FF8D3A" />
                                <path opacity="0.35" fill-rule="evenodd" clip-rule="evenodd"
                                    d="M68.5485 57.2027L76.2259 49.2691C77.0196 48.448 77.2968 47.2553 76.9441 46.1696C76.5913 45.0839 75.6673 44.2818 74.5417 44.0844L63.6683 42.1797C63.5423 42.1566 63.4226 42.1062 63.3197 42.0327C63.2168 41.9571 63.1307 41.8605 63.0719 41.7471L57.8997 31.9929C57.3642 30.9871 56.3164 30.355 55.174 30.355V67.1039C55.3021 67.1039 55.4281 67.1333 55.5436 67.1879L65.4595 72.0387C66.4864 72.5406 67.7043 72.4335 68.6283 71.7636C69.5523 71.0916 70.029 69.9661 69.8694 68.8342L68.3217 57.904C68.3028 57.778 68.3154 57.6479 68.3553 57.5261C68.3931 57.4064 68.4603 57.2951 68.5485 57.2027Z"
                                    fill="#FF8D3A" />
                                <defs>
                                    <filter id="filter0_d_1_981" x="0.173828" y="0.35498" width="110" height="110"
                                        filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                        <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                                        <feOffset dy="4" />
                                        <feGaussianBlur stdDeviation="10" />
                                        <feColorMatrix type="matrix"
                                            values="0 0 0 0 0.090196 0 0 0 0 0.0588235 0 0 0 0 0.286275 0 0 0 0.08 0" />
                                        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1_981" />
                                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1_981"
                                            result="shape" />
                                    </filter>
                                </defs>
                            </svg>
                        </div>
                        <div class="flex gap- flex-col">
                            <div class="font-bold"> {{ headTitle }} </div>
                            <div class="flex items-center gap-2 mb-0">
                                <span> Browse all </span>
                                <span>
                                    <svg class="w-[13px] h-[13px]" viewBox="0 0 13 15" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.81116 4.12012L11.8112 9.12012L6.81116 14.1201" stroke="#6F6C90"
                                            stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M11.811 9.11963L1.17383 9.11963" stroke="#6F6C90" stroke-width="1.6"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>

                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </Link>


        </div>
    </div>
</template>
