<script setup>
import { Head, Link, useForm, router, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted, watchEffect } from 'vue';

const props = defineProps({
    // sliders: {
    //     type: Object,
    //     default: {}
    // },
});

</script>
<template>
    <div>
        <div class="hero-section  relative mt-[141px] container">
            <div class="flex justify-center items-center  h-full ">
                <div class="flex flex-col items-center z-[2] px-2">
                    <div class="document-wrap mb-[24px]">
                        <h1 class="lg:text-5xl text-3xl text-center mb-[10px] font-bold ">
                            Search Over <span class="text-primary"> 20,000 + </span> Things To <br
                                class="lg:flex hidden">
                            Do in Ruby
                        </h1>
                        <h3 class="text-base text-center text-gray-500 mt-6">In the ever-evolving landscape of skills
                            and
                            knowledge, <br class="lg:flex hidden">
                            the choice between hiring an expert.</h3>
                    </div>
                    <div class="button-group flex  items-center gap-2 border p-1 rounded-full">
                        <svg class="md:ml-[24px] ml-[10px] sm:w-8 w-14"  viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1_886)">
                                <path
                                    d="M17.6125 15.4923C18.7935 13.8795 19.4999 11.8985 19.4999 9.75096C19.4999 4.375 15.1259 0.000976562 9.74993 0.000976562C4.37398 0.000976562 0 4.375 0 9.75096C0 15.1269 4.37403 19.5009 9.74998 19.5009C11.8975 19.5009 13.8787 18.7944 15.4915 17.6134L21.8789 24.0008L24 21.8798C24 21.8797 17.6125 15.4923 17.6125 15.4923ZM9.74998 16.5009C6.02781 16.5009 3.00001 13.4731 3.00001 9.75096C3.00001 6.02879 6.02781 3.00099 9.74998 3.00099C13.4721 3.00099 16.4999 6.02879 16.4999 9.75096C16.4999 13.4731 13.4721 16.5009 9.74998 16.5009Z"
                                    fill="#0F335E" />
                            </g>
                            <defs>
                                <clipPath id="clip0_1_886">
                                    <rect width="24" height="24" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>



                        <input type="text" placeholder="Search here..."
                            class="w-full border-none md:min-w-[400px] focus:ring-0 flex">
                        <button class="bg-primary rounded-full px-[16px] py-[10px] text-white flex items-center gap-2">
                            <span>Search</span>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_235_30)">
                                    <path
                                        d="M10.0433 12.357L11.2218 13.5355L14.7573 9.99995L11.2218 6.46442L10.0433 7.64293L11.567 9.16662H5.28602V10.8333H11.567L10.0433 12.357Z"
                                        fill="white" />
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M16.4818 16.4817C20.0616 12.9019 20.0616 7.09791 16.4818 3.51811C12.902 -0.0616995 7.098 -0.0616995 3.5182 3.51811C-0.061608 7.09791 -0.061608 12.9019 3.5182 16.4817C7.098 20.0615 12.902 20.0615 16.4818 16.4817ZM15.3033 15.3032C18.2322 12.3743 18.2322 7.62555 15.3033 4.69662C12.3744 1.76769 7.62564 1.76769 4.69671 4.69662C1.76778 7.62555 1.76778 12.3743 4.69671 15.3032C7.62564 18.2322 12.3744 18.2322 15.3033 15.3032Z"
                                        fill="white" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_235_30">
                                        <rect width="20" height="20" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </button>


                    </div>
                    <div class="flex items-center justify-center mt-[45px] lg:w-[60%]">
                        <div class="category-title flex flex-wrap items-center justify-center gap-2  ">
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            English Language
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Plumber
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Makeup
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Lawyers
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Fitness
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Musician
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Dancer
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Driver
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Designers
                            </Link>
                            <Link class="border-gray-200  border px-[15px] py-1 rounded-full hover:bg-gray-50 wrap ">
                            Developers
                            </Link>

                        </div>
                    </div>
                </div>
            </div>
            <div>
                <img src="/images/icons/women.png" class="absolute -top-20 left-40 lg:flex hidden" alt="">
                <img src="/images/icons/girl.png" class="absolute right-0 -top-20 lg:flex hidden" alt="">
                <img src="/images/icons/noto_fire.png" class="absolute right-0 -top-0 lg:flex hidden" alt="">
                <img src="/images/icons/time.png" class="absolute left-0 bottom-28 lg:flex hidden"  alt="">
                <img src="/images/icons/womengroup.png" class="absolute bottom-0 left-20 lg:flex hidden" alt="">
                <img src="/images/icons/arrow.png" class="absolute bottom-20 right-0 " alt="">
                <img src="/images/icons/Rectangle1.png" class="absolute bottom-20 right-40 lg:flex hidden" alt="">
                <img src="/images/icons/Rectangle2.png" class="absolute top-20 right-60 lg:flex hidden" alt="">
            </div>
        </div>
    </div>
</template>
