<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
const props = defineProps({
    // slugs: {
    //     type: Object,
    //     default: {}
    // },
});
const adata = [1,2,3,4,5,6,7,8];
</script>
<template>
    <div>
        <div class="popular-searches-wrap container ">
            <div class="title">
                <h2 class="text-[28px] text-left font-bold mb-[30px]">
                    Browse over   <span class="text-secondary">Multiple</span> Things
                </h2>
                <div class="grid lg:grid-cols-4 gap-[42px] md:grid-cols-4 sm:grid-cols-2 grid-cols-1">
                    <div class="child-services relative" v-for="dat in adata">
                         <h3 class="text-lg font-bold"> Tutors <span class="count">(12345) </span>  </h3>
                        <ul class="mt-[26px] flex gap-[20px] flex-col text-lg text-gray-600">
                            <li>Email Marketing</li>
                            <li>Paid Avertising</li>
                            <li>SEO & SEM</li>
                            <li>Funnel Optimization</li>
                            <li>Content Marketing</li>
                            <li>Email Marketing</li>
                            <li>Social Media</li>
                        </ul>
                        <Link>
                        <h3 class="text-primary font-bold mt-[20px]">See More +</h3>
                    </Link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

