<script setup>
import { ref } from 'vue';
import { Head, Link, useForm } from "@inertiajs/vue3"
import Header from '@/Pages/Frontend/Header.vue';
import Footer from '@/Pages/Frontend/Footer.vue';
import AllContact from '@/Pages/Frontend/Ankcomponents/AllContact.vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';
// import RequestForm from '@/Pages/Frontend/RequestForm.vue';
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import FormFilePicker from '@/Components/FormFilePicker.vue'

const modules = ref([Autoplay, Pagination, Navigation]);

const props = defineProps({
    teamcategories: {
        type: Object,
        default: () => ({}),
    },
    job_first: {
        type: Object,
        default: () => ({}),
    },
    jobOpeningIndex: {
        type: Object,
        default: '',
    },
    isJobField: {
        type: Boolean,
        default: true,
    },
    isJobField: {
        type: Boolean,
        default: false,
    },
});

const form = useForm({
    name: '',
    email: '',
    phone: '',
    image: '',
    // job_category_id: '',
    description: ''
})

// const contactDataJob = computed(() => ({

// }))
</script>

<template>
    <div>
        <Header />
        <div class="jobopening mt-[80px] my-[80px] container">
            <div class="jobopening-wrap">
                <div class="grid lg:grid-cols-2 gap-[81px]">
                    <div class="left">
                        <h1 class="text-[56px] font-bold">Job Openings</h1>
                        <div class="paragraph text-textcolor mt-[24px]">
                            {{ job_first.name }}
                        </div>
                        <img :src="'/storage/' + job_first.image"
                            class="aspect-video mt-[16px] object-cover rounded-[10px]" alt="">
                    </div>
                    <div class="right">
                        <div class="faq-body mt-[50px]">
                            <div class="faq-wrap">
                                <div class="faq-wrap">

                                    <div class="hs-accordion-group divide-y divide-gray-200  border-b"
                                        v-for="(jobs_cat, index) in teamcategories">
                                        <div class="hs-accordion py-[20px] " :class="index == 0 ? 'active' : ''"
                                            :id="'hs-basic-with-title-and-arrow-stretched-heading-one-' + index">
                                            <button
                                                class="hs-accordion-toggle group pb-3 inline-flex items-center justify-between gap-x-3 w-full md:text-[32px] leading-[41.6px] font-semibold text-start text-gray-800 rounded-lg transition hover:text-gray-500 ">
                                                {{ jobs_cat.name }}
                                                <svg class="hs-accordion-active:hidden block flex-shrink-0 size-5 text-gray-600 group-hover:text-gray-500 "
                                                    xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="m6 9 6 6 6-6" />
                                                </svg>
                                                <svg class="hs-accordion-active:block hidden flex-shrink-0 size-5 text-gray-600 group-hover:text-gray-500 "
                                                    xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="m18 15-6-6-6 6" />
                                                </svg>
                                            </button>
                                            <div :id="'hs-basic-with-title-and-arrow-stretched-collapse-one' +  index"
                                                class="hs-accordion-content w-full overflow-hidden  transition-[height] duration-300"
                                                :class="index != 0 ? 'hidden' : ''">
                                                <div class="flex flex-col my-[32px]" v-for="(jobs_data, index) in jobs_cat.jobs">
                                                    <div>
                                                    <div class="content1">
                                                        <div class="top-part flex justify-between items-center">
                                                            <div class="left">
                                                                <h3 class="job-title text-xl font-bold">{{
                                                                    jobs_data.name }}</h3>
                                                                <h4 class="text-base">{{ jobs_data.location }}</h4>
                                                            </div>
                                                            <div class="right">
                                                                <button
                                                                    :data-hs-overlay="'#hs-vertically-centered-modalapply-' + jobs_data.id"
                                                                    class="py-[8px] px-[20px] bg-primary hover:bg-secondary duration-500 text-white rounded-[8px]">
                                                                    Apply Now
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div class="bottom mt-[24px] text-base text-customblack !line-clamp-2"
                                                            v-html="jobs_data.description">
                                                        </div>
                                                    </div>
                                                    <!-- {{ isJobField }} -->
                                                    <!-- form -->
                                                    <!-- <RequestForm :isJobField="isJobField" :isinputVisible="isinputVisible" isJObOpeningModal :jobOpeningIndex="jobs_data.id" /> -->
                                                    <div :id="'hs-vertically-centered-modalapply-' + jobs_data.id"
                                                        class="hs-overlay hs-overlay-open:bg-black backdrop-blur-sm bg-opacity-50 w-full hidden size-full fixed top-0 start-0 z-[80] overflow-x-hidden overflow-y-auto pointer-events-none">
                                                        <div
                                                            class="hs-overlay-open:mt-7  hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all max-w-[416px] max-h-full m-3 mx-auto h-[calc(100%-3.5rem)] min-h-[calc(100%-3.5rem)] flex items-center">
                                                            <div
                                                                class="w-full max-h-full overflow-hidden flex flex-col bg-white border shadow-sm rounded-xl pointer-events-auto dark:bg-neutral-800 dark:border-neutral-700 dark:shadow-neutral-700/70">
                                                                <div
                                                                    class="flex justify-between items-center py-3 px-4  dark:border-neutral-700">
                                                                    <button type="button"
                                                                        class="text-gray-400  mt-[10px] bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm ms-auto inline-flex justify-center items-center"
                                                                        :data-hs-overlay="'#hs-vertically-centered-modalapply-' + jobs_data.id">
                                                                        <span class="sr-only">Close</span>
                                                                        <svg width="40" height="40" viewBox="0 0 40 40"
                                                                            fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <g clip-path="url(#clip0_500_14801)">
                                                                                <path
                                                                                    d="M20.0002 17.6436L28.2502 9.39355L30.6069 11.7502L22.3569 20.0002L30.6069 28.2502L28.2502 30.6069L20.0002 22.3569L11.7502 30.6069L9.39355 28.2502L17.6436 20.0002L9.39355 11.7502L11.7502 9.39355L20.0002 17.6436Z"
                                                                                    fill="#94A4C1" />
                                                                            </g>
                                                                            <defs>
                                                                                <clipPath id="clip0_500_14801">
                                                                                    <rect width="40" height="40"
                                                                                        fill="white" />
                                                                                </clipPath>
                                                                            </defs>
                                                                        </svg>
                                                                    </button>
                                                                </div>
                                                                <div>
                                                                    <div>
                                                                        <div class="header">
                                                                            <h3
                                                                                class="text-[40px] font-bold text-gray-900 text-center leading-[48px] pt-[24px]">
                                                                                Apply Now
                                                                            </h3>
                                                                        </div>
                                                                        <CardBox form
                                                                            @submit.prevent="form.post(route('JobFeedbackSubmitRequest', jobs_data.id))"
                                                                            ankcustomClass>
                                                                            <div>
                                                                                <FormField
                                                                                    :class="{ 'text-red-400': form.errors.name }">
                                                                                    <FormControl v-model="form.name"
                                                                                        type="text"
                                                                                        placeholder="Your Name"
                                                                                        :error="form.errors.name">
                                                                                        <div class="text-red-400 text-sm"
                                                                                            v-if="form.errors.name">
                                                                                            {{ form.errors.name }}
                                                                                        </div>
                                                                                    </FormControl>
                                                                                </FormField>
                                                                                <FormField
                                                                                    :class="{ 'text-red-400': form.errors.email }">
                                                                                    <FormControl v-model="form.email"
                                                                                        type="email"
                                                                                        placeholder="Your Email"
                                                                                        :error="form.errors.email">
                                                                                        <div class="text-red-400 text-sm"
                                                                                            v-if="form.errors.email">
                                                                                            {{ form.errors.email }}
                                                                                        </div>
                                                                                    </FormControl>
                                                                                </FormField>
                                                                                <FormField
                                                                                    :class="{ 'text-red-400': form.errors.phone }">
                                                                                    <FormControl v-model="form.phone"
                                                                                        type="number"
                                                                                        placeholder="Your Phone"
                                                                                        :error="form.errors.phone">
                                                                                        <div class="text-red-400 text-sm"
                                                                                            v-if="form.errors.phone">
                                                                                            {{ form.errors.phone }}
                                                                                        </div>
                                                                                    </FormControl>
                                                                                </FormField>
                                                                            </div>
                                                                            <div class="mt-6">
                                                                                <FormField
                                                                                    :class="{ 'text-red-400 text-sm ': form.errors.description }">
                                                                                    <FormControl ankcstmclass
                                                                                        v-model="form.description"
                                                                                        type="text"
                                                                                        placeholder="Your Message"
                                                                                        :error="form.errors.description">
                                                                                        <div class="text-red-400 text-sm"
                                                                                            v-if="form.errors.description">
                                                                                            {{ form.errors.description
                                                                                            }}
                                                                                        </div>
                                                                                    </FormControl>
                                                                                </FormField>
                                                                            </div>
                                                                            <div class="my-6">
                                                                                <div class="relative">
                                                                                    <label for="input-attach">
                                                                                        <div
                                                                                            class="flex items-center gap-2">
                                                                                            <svg width="24" height="24"
                                                                                                viewBox="0 0 24 24"
                                                                                                fill="none"
                                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                                <path
                                                                                                    d="M12.2028 11.8L10.7928 13.21C10.0128 13.99 10.0128 15.26 10.7928 16.04C11.5728 16.82 12.8428 16.82 13.6228 16.04L15.8428 13.82C17.4028 12.26 17.4028 9.72999 15.8428 8.15999C14.2828 6.59999 11.7528 6.59999 10.1828 8.15999L7.76281 10.58C6.42281 11.92 6.42281 14.09 7.76281 15.43"
                                                                                                    stroke="#004745"
                                                                                                    stroke-width="1.5"
                                                                                                    stroke-linecap="round"
                                                                                                    stroke-linejoin="round" />
                                                                                                <path
                                                                                                    d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
                                                                                                    stroke="#004745"
                                                                                                    stroke-width="1.5"
                                                                                                    stroke-linecap="round"
                                                                                                    stroke-linejoin="round" />
                                                                                            </svg>
                                                                                            <div
                                                                                                class="text-primary font-bold underline">
                                                                                                Attach CV
                                                                                            </div>
                                                                                        </div>
                                                                                    </label>
                                                                                    <FormField
                                                                                        class="opacity-0 absolute z-40 bottom-0 bg-red-100"
                                                                                        :class="{ 'text-red-400': form.errors.image }">
                                                                                        <FormFilePicker
                                                                                            id="input-attach"
                                                                                            placeholder="Image"
                                                                                            v-model="form.image"
                                                                                            :error="form.errors.image"
                                                                                            type="file" />
                                                                                        <div class="text-red-400 text-sm"
                                                                                            v-if="form.errors.image">
                                                                                            {{ form.errors.image }}
                                                                                        </div>
                                                                                    </FormField>
                                                                                </div>
                                                                            </div>
                                                                            <div>
                                                                                <button
                                                                                    :data-hs-overlay="'#hs-vertically-centered-modalapply-' + jobs_data.id"
                                                                                    class="py-[8px] px-[20px] mb-[20px]  bg-primary hover:bg-secondary border-2 w-full duration-500 text-white rounded-[8px]">
                                                                                    <span>Send</span>
                                                                                </button>
                                                                            </div>



                                                                        </CardBox>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <!-- form -->
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <Footer />
    </div>
</template>

