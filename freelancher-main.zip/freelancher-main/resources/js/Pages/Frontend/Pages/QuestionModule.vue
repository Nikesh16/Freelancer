<script setup>
import { ref } from 'vue';
import { Head, Link } from '@inertiajs/vue3';
import Header from '@/Pages/Frontend/Header.vue';
import Footer from '@/Pages/Frontend/Footer.vue';
import AllContact from '@/Pages/Frontend/Ankcomponents/AllContact.vue';
import FixedContact from '@/Pages/Frontend/Ankcomponents/FixedContact.vue';
import MainButton from '@/Pages/Frontend/Ankcomponents/MainButton.vue';
const props = defineProps({
    // ourTeams: {
    //     type: Object,
    //     default: () => ({}),
    // },
});
const activeQuestiontab = ref('Orders')
</script>
<template>
    <div>
        <Header />
        <div class="question my-[80px]  container">
            <div class="question-wrap grid grid-cols-12 gap-8">
                <div class="question-left lg:col-span-3 col-span-12">
                    <div class="question-left-wrap rounded-[14px]">
                        <ul class="flex flex-col gap-[20px]">
                            <li @click="activeQuestiontab = 'Orders'"
                                class="progress flex  flex-col gap-2 justify-center  p-6 rounded-[14px] cursor-pointer"
                                :class="activeQuestiontab == 'Orders' ? 'bg-agray' : 'border'">
                                <div>
                                    <div class="top p-4 bg-white w-full  flex justify-center rounded-[12px] shadow-sm">
                                        <div class="round w-[131px] h-[131px] flex border-[16px] rounded-full">

                                       </div>
                                            <!-- <svg viewBox="0 0 80 80">
                                                <circle class="pie1 " cx="40" cy="40" r="15.9154943092"
                                                    stroke-dasharray="200,200,0,0" data-percent="60" />
                                            </svg> -->
                                    </div>
                                </div>
                                <div class="flex flex-col items-start mt-2">
                                    <div class="font-bold"> Orders </div>
                                    <div>
                                        <span> 70 % Full </span>
                                    </div>
                                </div>
                            </li>
                            <li class="tab hover:bg-agray rounded-[14px] cursor-pointer"
                                @click="activeQuestiontab = 'Support'"
                                :class="activeQuestiontab == 'Support' ? 'bg-agray' : ''">
                                <MainButton headTitle="Support" isquestion />
                            </li>
                            <li class="tab hover:bg-agray rounded-[14px] cursor-pointer"
                                @click="activeQuestiontab = 'Specialist'"
                                :class="activeQuestiontab == 'Specialist' ? 'bg-agray' : ''">
                                <MainButton headTitle="Specialist" isquestion />
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="question-right lg:col-span-9 col-span-12">
                    <div class="question-right-wrap bg-agray p-4 rounded-[14px]">
                        <div class="Orders" v-if="activeQuestiontab == 'Orders'">
                            Orders
                        </div>
                        <div class="Support" v-if="activeQuestiontab == 'Support'">
                            Support
                        </div>
                        <div class="Specialist" v-if="activeQuestiontab == 'Specialist'">
                            Specialist
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>

<style>
circle {
    fill: rgba(0, 0, 0, 0);
    stroke-width: 6;
    stroke-dashoffset: 25;
    -webkit-animation: pie1 3s infinite ease both;
    animation: pie1 6s infinite ease both;
}

.pie1 {
    stroke: #e1137a;
}

.pie1::before {
    content: '100%';
    display: inline-block;
    width: 25px;
    height: 25px;
    color: black;
    position: absolute;
    top: 0;
    left: 0;
}
</style>
