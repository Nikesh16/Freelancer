<script setup>
import { Head, Link, useForm, usePage, router } from '@inertiajs/vue3';
import { ref, reactive, computed, onMounted, onUnmounted, onBeforeUnmount } from 'vue';

const props = defineProps({
    cms: {
        type: Object,
        default: {}
    },
    canLogin: Boolean,
    canRegister: Boolean,
    laravelVersion: String,
    phpVersion: String,
    ispadding: String,
});



const isSticky = ref(false);

const handleScroll = () => {
    const currentScroll = window.pageYOffset;
    isSticky.value = currentScroll > 150;
};

onMounted(() => {
    window.addEventListener('scroll', handleScroll);
});

onBeforeUnmount(() => {
    window.removeEventListener('scroll', handleScroll);
});

const page = usePage()

const general_setting = computed(() => page.props.general_setting.setting);

</script>
<template>
    <div>
        <header :class="{ 'is-sticky': isSticky }"
            class="flex flex-wrap aheader border-b xl:justify-start xl:flex-nowrap z-50 w-full bg-white  py-4 ">
            <nav class="container w-full  xl:flex xl:items-center xl:justify-between gap-4" aria-label="Global">
                <div class="flex items-center justify-between gap-[37px]">
                    <Link :href="'/'" class="flex  items-center gap-2">
                    <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="45" height="45" rx="9" fill="#FF9800" />
                        <path
                            d="M15.04 17L13.288 13.82H12.796V17H10.744V8.576H14.188C14.852 8.576 15.416 8.692 15.88 8.924C16.352 9.156 16.704 9.476 16.936 9.884C17.168 10.284 17.284 10.732 17.284 11.228C17.284 11.788 17.124 12.288 16.804 12.728C16.492 13.168 16.028 13.48 15.412 13.664L17.356 17H15.04ZM12.796 12.368H14.068C14.444 12.368 14.724 12.276 14.908 12.092C15.1 11.908 15.196 11.648 15.196 11.312C15.196 10.992 15.1 10.74 14.908 10.556C14.724 10.372 14.444 10.28 14.068 10.28H12.796V12.368Z"
                            fill="#FF9800" />
                        <path
                            d="M27.76 8.576V13.616C27.76 14.12 27.884 14.508 28.132 14.78C28.38 15.052 28.744 15.188 29.224 15.188C29.704 15.188 30.072 15.052 30.328 14.78C30.584 14.508 30.712 14.12 30.712 13.616V8.576H32.764V13.604C32.764 14.356 32.604 14.992 32.284 15.512C31.964 16.032 31.532 16.424 30.988 16.688C30.452 16.952 29.852 17.084 29.188 17.084C28.524 17.084 27.928 16.956 27.4 16.7C26.88 16.436 26.468 16.044 26.164 15.524C25.86 14.996 25.708 14.356 25.708 13.604V8.576H27.76Z"
                            fill="#FF9800" />
                        <path
                            d="M15.844 30.68C16.332 30.784 16.724 31.028 17.02 31.412C17.316 31.788 17.464 32.22 17.464 32.708C17.464 33.412 17.216 33.972 16.72 34.388C16.232 34.796 15.548 35 14.668 35H10.744V26.576H14.536C15.392 26.576 16.06 26.772 16.54 27.164C17.028 27.556 17.272 28.088 17.272 28.76C17.272 29.256 17.14 29.668 16.876 29.996C16.62 30.324 16.276 30.552 15.844 30.68ZM12.796 29.984H14.14C14.476 29.984 14.732 29.912 14.908 29.768C15.092 29.616 15.184 29.396 15.184 29.108C15.184 28.82 15.092 28.6 14.908 28.448C14.732 28.296 14.476 28.22 14.14 28.22H12.796V29.984ZM14.308 33.344C14.652 33.344 14.916 33.268 15.1 33.116C15.292 32.956 15.388 32.728 15.388 32.432C15.388 32.136 15.288 31.904 15.088 31.736C14.896 31.568 14.628 31.484 14.284 31.484H12.796V33.344H14.308Z"
                            fill="#FF9800" />
                        <path
                            d="M31.968 26.576L29.052 32.216V35H27V32.216L24.084 26.576H26.412L28.044 30.104L29.664 26.576H31.968Z"
                            fill="#FF9800" />
                        <path
                            d="M24.4 30L21.48 24.7H20.66V30H17.24V15.96H22.98C24.0867 15.96 25.0267 16.1533 25.8 16.54C26.5867 16.9267 27.1733 17.46 27.56 18.14C27.9467 18.8067 28.14 19.5533 28.14 20.38C28.14 21.3133 27.8733 22.1467 27.34 22.88C26.82 23.6133 26.0467 24.1333 25.02 24.44L28.26 30H24.4ZM20.66 22.28H22.78C23.4067 22.28 23.8733 22.1267 24.18 21.82C24.5 21.5133 24.66 21.08 24.66 20.52C24.66 19.9867 24.5 19.5667 24.18 19.26C23.8733 18.9533 23.4067 18.8 22.78 18.8H20.66V22.28Z"
                            fill="white" />
                    </svg>
                    <span class="font-bold">RUBY</span>
                    </Link>

                    <select name="" class="border border-gray-200 rounded-full px-[16px] py-[10px]" id="">
                        <option value="">Moscow</option>
                    </select>

                </div>
                <div id="navbar-collapse-with-animation"
                    class="hs-collapse hidden overflow-hidden  transition-all duration-300 basis-full grow xl:block text-customblack ">
                    <div
                        class="flex flex-col gap-[30px] mt-5  xl:justify-end xl:flex-row xl:items-center  xl:mt-0 xl:px-2">
                        <Link class="text-customblack font-medium" aria-current="page">How it Works</Link>
                        <a class=" text-customblack font-medium hover:text-secondary ">Contact</a>
                        <button class="bg-primary rounded-full px-[16px] py-[10px] text-white flex items-center gap-2">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M13 15H7C6.73478 15 6.48043 14.8946 6.29289 14.7071C6.10536 14.5196 6 14.2652 6 14V12.5H7V14H13V2H7V3.5H6V2C6 1.73478 6.10536 1.48043 6.29289 1.29289C6.48043 1.10536 6.73478 1 7 1H13C13.2652 1 13.5196 1.10536 13.7071 1.29289C13.8946 1.48043 14 1.73478 14 2V14C14 14.2652 13.8946 14.5196 13.7071 14.7071C13.5196 14.8946 13.2652 15 13 15Z"
                                    fill="#F2F2F2" stroke="#F2F2F2" stroke-width="0.5" />
                                <path d="M7.295 10.295L9.085 8.5H2V7.5H9.085L7.295 5.705L8 5L11 8L8 11L7.295 10.295Z"
                                    fill="#F2F2F2" stroke="#F2F2F2" stroke-width="0.5" />
                            </svg>
                            <span>Login</span>
                        </button>
                    </div>
                </div>
            </nav>
        </header>
    </div>
</template>

<style>
.aheader.is-sticky {
    position: fixed;
    top: 0;
    box-shadow: 0 5px 16px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    animation: slideDown 0.35s ease-out;
    border: none;
}

.aheader.is-sticky img {
    max-width: 80%;
}

.aheader.is-sticky button {
    /* font-size: 14px */
    padding: 7px 10px;
}

@keyframes slideDown {
    from {
        transform: translateY(-100%);
    }

    to {
        transform: translateY(0);
    }
}
</style>
