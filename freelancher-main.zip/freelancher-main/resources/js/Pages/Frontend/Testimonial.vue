<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const modules = ref([Autoplay, Pagination, Navigation]);
const props = defineProps({
    testimonials: {
        type: Object,
        default: () => ({}),
    },
});
const atestimonials = [1, 2, 3, 4, 5, 6]
const arate = [1, 2, 3, 4, 5]
</script>
<template>
    <div>
        <div class="whatweget container">
            <div class="whatweget-wrap">

                <div class="get-body ">
                    <div class="flex justify-center flex-col gap-2 items-center">
                        <div class="batch bg-lightprimary px-3 rounded-full text-primary max-w-max">
                            <span>Testimonials</span>
                        </div>
                        <h2 class="sm:text-4xl text-2xl font-bold">
                            Our Reviews
                        </h2>
                    </div>

                    <div  class="testimonial grid lg:grid-cols-2 grid-cols-1 gap-4 mt-[40px]">
                        <div class="review-tile" v-for="testimonial in atestimonials">
                            <div class="review-wrap border rounded-[20px] border-gray-200 p-4 flex flex-col gap-3">
                                <div class="top-part">
                                    <div class="flex items-center gap-2">
                                        <div class="left">
                                            <img src="/images/icons/women.png" alt="">
                                        </div>
                                        <div class="right flex flex-col">
                                            <h2 class="text-lg">John Doe</h2>
                                            <h3 class="text-sm text-gray-400">Professor</h3>
                                            <div class=" rating flex gap-1 items-center">
                                                <span v-for="(rate,index) in arate">
                                                    <svg class="w-[14px] h-[14px]" viewBox="0 0 17 17" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_1_1452)">
                                                            <path
                                                                d="M16.9543 6.62272H10.5284L8.54234 0.511719L6.57135 8.59472L8.54234 12.7347L13.7424 16.5117L11.7563 10.4007L16.9543 6.62272Z"
                                                                 :class="index>=4?'stroke-[.4px] stroke-textcolor ':'fill-primary'" />
                                                            <path
                                                                d="M6.55735 6.62272H0.131348L5.33135 10.3997L3.34435 16.5117L8.54435 12.7347V0.511719L6.55735 6.62272Z"
                                                                 :class="index>=5?'stroke-[.4px] stroke-textcolor  ':'fill-primary'" />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_1_1452">
                                                                <rect x="0.131348" y="0.511719" width="16.823"
                                                                    height="16" rx="8" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bottom-part text-textcolor">
                                    Contrary to popular belief, Lore Ipsum is not simply random text.
                                    It has roots in a piece.Contrary to popular belief, Lore Ipsum is not
                                    simply random text. It has roots in a piece.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
