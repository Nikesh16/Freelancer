<script setup>
import { ref } from 'vue';
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { computed, onMounted, onUnmounted } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const modules = ref([Autoplay, Pagination, Navigation]);

const props = defineProps({
    clients: {
        type: Object,
        default: {}
    },
});
</script>
<template>
    <div class="counter-section container ">
        <div class="about-section relative flex flex-col items-center justify-center">
            <div class="title group">
                <div class="title-wrap flex flex-col justify-center items-center relative">
                    <!-- <div class="short-title capitalize text-primary mb-1 rounded-full  px-2  bg-primary bg-opacity-40">
                        Clients</div> -->
                    <div class="main-title uppercase text-[34px] dark:text-slate-200 font-semibold mb-2">Our Clients
                    </div>
                    <div class="line w-full h-[.3px] bg-hardgray flex items-center justify-center ">
                        <div class="line-sub w-[30%] bg-primary h-1 rounded-md group-hover:w-full duration-1000">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- {{ clients }} -->
        <div class="mt-6">
            <swiper class=" flex justify-center " :spaceBetween="30" :slidesPerView="2" :loop="true" :centeredSlides="true"
                :autoplay="{
                    delay: 5000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                }" :navigation="false" :modules="modules" :breakpoints="{
    '640': {
        slidesPerView: 3,
        spaceBetween: 20,
    },
    '768': {
        slidesPerView: 4,
        spaceBetween: 40,
    },
    '1024': {
        slidesPerView: 7,
        spaceBetween: 50,
    },
}">
                <swiper-slide v-for="client in clients" :key="client.id">
                    <div class="client p-2">
                        <img :src="'/storage/' + client.image"
                            class="w-full hover:scale-[1.05]  duration-500 aspect-square  h-full object-contain"
                            alt="">
                    </div>
                </swiper-slide>
            </swiper>
        </div>
    </div>
</template>

