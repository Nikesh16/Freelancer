<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

const modules = ref([Autoplay, Pagination, Navigation]);
const props = defineProps({
    howitworks: {
        type: Object,
        default: () => ({}),
    },
});
const ahowitworks = [1, 2, 3, 4, 5, 6]
</script>
<template>
    <div>
        <div class="whatweget container">
            <div class="whatweget-wrap">

                <div class="get-body ">
                    <div class="flex justify-center flex-col gap-2 items-center">
                        <div class="batch bg-lightprimary px-3 rounded-full text-primary max-w-max">
                            <span>Flow</span>
                        </div>
                        <h2 class="sm:text-4xl text-2xl font-bold">
                            How It Works
                        </h2>
                    </div>
                    <swiper class=" flex justify-center items-center mt-[40px]" :spaceBetween="30" :slidesPerView="1" :loop="true"
                        :autoplay="{
                            delay: 5000,
                            disableOnInteraction: false,
                            pauseOnMouseEnter: true,
                        }" :navigation="false" :modules="modules" :breakpoints="{
                            '640': {
                                slidesPerView: 1,
                                spaceBetween: 10,
                            },
                            '768': {
                                slidesPerView: 2,
                                spaceBetween: 20,
                            },
                            '1024': {
                                slidesPerView: 3,
                                spaceBetween: 30,
                            },
                        }">
                        <swiper-slide v-for="(howitwork, index) in ahowitworks" :key="howitwork.id">
                            <div
                                class="py-10 px-4 hover:bg-gray-50  h-full flex justify-center items-center rounded-[20px]">
                                <div class="news-tile rounded-t-[10px] ">
                                    <Link>
                                    <div class="news-tile-wrap flex flex-col items-center justify-center">
                                        <div class="top-news h-[200px]  relative">
                                            <img v-if="howitwork.image"
                                                class="rounded-t-[10px] aspect-video h-full object-cover"
                                                :src="'/storage/' + howitwork.image" alt="" />
                                            <img v-else class="rounded-t-[10px] aspect-video h-full object-cover"
                                                :src="index % 2 != 0 ? '/images/icons/Icon-2.png' : '/images/icons/Icon-1.png'"
                                                alt="" />
                                        </div>
                                        <div class="bottom  flex flex-col justify-center items-center">
                                            <h2 class="font-[600] text-[22px] text-center leading-[30px] mt-[41px]">
                                                Leave
                                                your order</h2>
                                            <h4 class="text-center text-textcolor text-lg mt-[23px]">
                                                Contrary to popular belief, Lore Ipsum is not simply random text. It has
                                                roots in a piece.
                                            </h4>
                                            <Link class="underline font-bold pb-[20px] mt-[40px]">
                                            Learn More
                                            </Link>
                                            <div class="flex items-center justify-center ">
                                                <span
                                                    class="w-10 h-10 flex justify-center items-center rounded-full bg-primary text-white">{{
                                                        index + 1 }}</span>
                                            </div>
                                        </div>
                                    </div>
                                    </Link>
                                </div>
                            </div>
                        </swiper-slide>
                    </swiper>

                </div>
            </div>
        </div>
    </div>
</template>
