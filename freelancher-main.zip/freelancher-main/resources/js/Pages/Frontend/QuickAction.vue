<script setup>
import { ref } from 'vue';
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { computed, onMounted, onUnmounted } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';
import MainButton from '@/Pages/Frontend/Ankcomponents/MainButton.vue';

const modules = ref([Autoplay, Pagination, Navigation]);

const props = defineProps({
    headTitle: {
        type: Object,
        default: ''
    },
});
</script>
<template>
    <div>
        <div class="grid lg:grid-cols-4 sm:grid-cols-2 grid-cols-1 container gap-4">
            <MainButton headTitle="Features"/>
            <MainButton headTitle="Use Cases"/>
            <MainButton headTitle="Resources"/>
            <MainButton headTitle="About Us"/>
        </div>
    </div>
</template>
