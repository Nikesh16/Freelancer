<script setup>
const props = defineProps({
    cmsData: {
        type: Object,
        default: {}
    },
});
</script>
<template>
    <div class="w-full">
        <div class="header-title mt- w-full">
            <div class="header-wrap bg-[#F1EFF0] w-full  h-[160px] relative w-full">
                <img class="absolute w-full h-full object-cover left-0" src="/images/mission.jpeg" alt="">
                <div class="absolute top-0 h-full bg-black bg-opacity-40 w-full left-0 object-cover ">
                </div>
                <div class="absolute  left-0 w-full h-full">
                    <div class="flex justify-center h-full items-center">
                        <div class="title flex items-center flex-col justify-center">
                            <div class="title lg:text-[32px] text-[18px] leading-[42px]  text-white font-Gilda"> {{ cmsData.cmstype }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="title group">
                <div class="title-wrap flex flex-col justify-center items-center relative">
                    <div class="short-title capitalize text-primary mb-1 rounded-full  px-2  bg-primary bg-opacity-40">
                        {{ cmsData.cmstype }}</div>
                    <div class="main-title uppercase text-[34px] dark:text-slate-200 font-semibold mb-2">{{ cmsData.cmstype
                    }}
                    </div>
                    <div class="line w-full h-[.3px] bg-hardgray flex items-center justify-center ">
                        <div class="line-sub w-[30%] bg-primary h-1 rounded-md group-hover:w-full duration-1000">
                        </div>
                    </div>
                </div>
            </div> -->
        </div>

    </div>
</template>
