<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { computed, onMounted, onUnmounted } from 'vue';
const aloopCount = [1,2,3,4,5,6,7,8]
</script>
<template>
    <div>
        <div class="popular-searches-wrap container ">
            <div class="title">
                <h2 class="text-[28px] text-left font-bold mb-[30px]">
                    Popular <span class="text-secondary">Searches </span>
                </h2>
                <div class="grid lg:grid-cols-4 gap-[23px] md:grid-cols-3 sm:grid-cols-2 grid-cols-1">
                    <div class="child-services relative" v-for="loopCount in aloopCount">
                        <img src="/images/plumber.png" class="aspect-video rounded-md w-full" alt="">
                        <div class="absolute bottom-2 left-2 z-10 text-white font-medium text-lg">
                            Plumber
                        </div>
                        <div class="absolute bg-gradient-to-t from-bg-customblack to-white"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
