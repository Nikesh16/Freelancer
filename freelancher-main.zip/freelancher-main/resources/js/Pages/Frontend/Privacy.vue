<script setup>
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted } from 'vue';
import Header from '@/Pages/Frontend/Header.vue';
import Footer from '@/Pages/Frontend/Footer.vue';
import Title from '@/Pages/Frontend/Title.vue';
const props = defineProps({
    cmsData: {
        type: Object,
        default: {}
    },
});
</script>
<template>
    <div>
        <Header class="shadow-md" />
        <section class="team">
            <div class="service-section relative flex flex-col items-center justify-center">
                <Title :cmsData="cmsData"/>
            </div>
            <div class="team-content mt-4 container">
                <section class="bg-white rounded-[12px]">
                    <div class=" mx-auto  gap-8">
                        <div>
                            <div class="border rounded-[12px] border-gray-200 ">
                                <div>
                                    <div
                                        class=" flex gap-4 p-4">
                                        <div
                                            class="relative group duration-500">
                                            <div class="designation pt-3">
                                                <div class="flex flex-col gap-1 z-[1] ">
                                                    <div class="name font-medium text-[18px]">
                                                        {{ cmsData.title }}</div>
                                                    <div class="designation text-[14px] text-gray-500" v-html="cmsData.description"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>
    <div class="container">
        <Footer />
    </div>
</template>
