<script setup>
import { ref, onMounted } from 'vue';
import { Head, Link } from '@inertiajs/vue3';
import Header from '@/Pages/Frontend/Header.vue';
import Hero from '@/Pages/Frontend/Hero.vue';
import Popularservices from '@/Pages/Frontend/Popularservices.vue';
import Service from '@/Pages/Frontend/Service.vue';
import Blogs from '@/Pages/Frontend/Blogs.vue';
import Banner from '@/Pages/Frontend/Banner.vue';
import Testimonial from '@/Pages/Frontend/Testimonial.vue';
import HowitWorks from '@/Pages/Frontend/HowitWorks.vue';
import Footer from '@/Pages/Frontend/Footer.vue';
import QuickAction from '@/Pages/Frontend/QuickAction.vue';
const props = defineProps({
    // faqs: {
    //     type: Object,
    //     default: () => ({}),
    // },
});
</script>

<template>

    <Head title="Welcome" />
    <Header />
    <Hero />
    <div class="mt-[80px]">
        <Popularservices />
    </div>
    <div class="mt-[40px]">
        <Service/>
    </div>
    <div class="my-[40px]">
        <QuickAction/>
    </div>
    <div class="my-[40px]">
        <Blogs/>
    </div>
    <div class="my-[40px]">
        <Banner/>
    </div>
    <div class="my-[40px]">
        <HowitWorks/>
    </div>
    <div class="my-[40px]">
        <Testimonial/>
    </div>
    <div class="my-[40px]">
        <Footer/>
    </div>


</template>
