<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import {
  mdiAccountKey,
  mdiArrowLeftBoldOutline
} from "@mdi/js"
import LayoutAuthenticated from "@/Layouts/LayoutAuthenticated.vue"
import SectionMain from "@/Components/SectionMain.vue"
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue"
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import FormCheckRadioGroup from '@/Components/FormCheckRadioGroup.vue'
import BaseDivider from '@/Components/BaseDivider.vue'
import BaseButton from '@/Components/BaseButton.vue'
import BaseButtons from '@/Components/BaseButtons.vue'
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import FormFilePicker from "@/Components/FormFilePicker.vue"

const props = defineProps({
  blog: {
    type: Object,
    default: () => ({}),
  },
  blog_category: {
    type: Object,
    default: () => ({}),
  },
})

const form = useForm({
  _method: 'put',
  name: props.blog.name,
  description: props.blog.description,
  image: '',
  meta_title: props.blog.meta_title,
  meta_description: props.blog.meta_description,
  meta_keyword: props.blog.meta_keyword,
  blog_category_id: props.blog.blog_category_id,
  status: props.blog.status == 1 ? true : false,
})
</script>

<template>
  <LayoutAuthenticated>

    <Head title="Update Blog" />
    <SectionMain>
      <SectionTitleLineWithButton :icon="mdiAccountKey" title="Update Blog" main>
        <BaseButton :route-name="route('admin.blog.index')" :icon="mdiArrowLeftBoldOutline" label="Back" color="white"
          rounded-full small />
      </SectionTitleLineWithButton>
      <CardBox form @submit.prevent="form.post(route('admin.blog.update', props.blog.id))">
        <FormField label="Name" :class="{ 'text-red-400': form.errors.name }">
          <FormControl v-model="form.name" type="text" placeholder="Enter Name" :error="form.errors.name">
            <div class="text-red-400 text-sm" v-if="form.errors.name">
              {{ form.errors.name }}
            </div>
          </FormControl>
        </FormField>
        <FormField label="Blog Category" :class="{ 'text-red-400': form.errors.blog_category_id }">
          <FormControl v-model="form.blog_category_id" ankcustomclass :options="blog_category" required>
            <div class="text-red-400 text-sm" v-if="form.errors.blog_category_id">
              {{ form.errors.blog_category_id }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Description" :class="{ 'text-red-400': form.errors.description }">

          <quill-editor v-model:content="form.description" name="description" toolbar="full" theme="snow"
            contentType="html"></quill-editor>
        </FormField>

        <FormField label="Meta title" :class="{ 'text-red-400': form.errors.meta_title }">
          <FormControl v-model="form.meta_title" type="text" placeholder="Enter meta title"
            :error="form.errors.meta_title">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_title">
              {{ form.errors.meta_title }}
            </div>
          </FormControl>
        </FormField>
        <FormField label="Meta Description" :class="{ 'text-red-400': form.errors.meta_description }">
          <FormControl v-model="form.meta_description" type="text" placeholder="Enter meta description"
            :error="form.errors.meta_description">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_description">
              {{ form.errors.meta_description }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Meta Keywords" :class="{ 'text-red-400': form.errors.meta_keyword }">
          <FormControl v-model="form.meta_keyword" type="text" placeholder="Enter meta keyword"
            :error="form.errors.meta_keyword">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_keyword">
              {{ form.errors.meta_keyword }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Image" :class="{ 'text-red-400': form.errors.image }">
          <FormFilePicker placeholder="Image" v-model="form.image" :error="form.errors.image" type="file" />
          <div class="text-red-400 text-sm" v-if="form.errors.image">
            {{ form.errors.image }}
          </div>
        </FormField>

        <FormCheckRadioGroup v-model="form.status" name="sample-switch" type="switch" class="mt-5"
          :options="{ two: 'Status' }" />

        <template #footer>
          <BaseButtons>
            <BaseButton type="submit" color="info" label="Submit" :class="{ 'opacity-25': form.processing }"
              :disabled="form.processing" />
          </BaseButtons>
        </template>
      </CardBox>
    </SectionMain>
  </LayoutAuthenticated>
</template>
