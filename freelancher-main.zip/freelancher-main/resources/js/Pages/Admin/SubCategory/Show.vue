<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import {
  mdiAccountKey,
  mdiArrowLeftBoldOutline,
} from "@mdi/js"
import LayoutAuthenticated from "@/Layouts/LayoutAuthenticated.vue"
import SectionMain from "@/Components/SectionMain.vue"
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue"
import CardBox from "@/Components/CardBox.vue"
import BaseButton from "@/Components/BaseButton.vue"

const props = defineProps({
  category: {
    type: Object,
    default: () => ({}),
  },
})
</script>

<template>
  <LayoutAuthenticated>

    <Head title="View Sub Category" />
    <SectionMain>
      <SectionTitleLineWithButton :icon="mdiAccountKey" title="View Sub Category" main>
        <BaseButton :route-name="route('admin.child_category.index')" :icon="mdiArrowLeftBoldOutline" label="Back" color="white"
          rounded-full small />
      </SectionTitleLineWithButton>
      <CardBox class="mb-6">
        <table>
          <tbody>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Name
              </td>
              <td data-label="Name">
                {{ category.name }}
              </td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Meta Title
              </td>
              <td data-label=" Meta Title">
                {{ category.meta_title }}
              </td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Meta Description
              </td>
              <td data-label="Meta Description">
                {{ category.meta_description }}
              </td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Meta Keywords
              </td>
              <td data-label="Meta Keywords">
                {{ category.meta_keyword }}
              </td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Description
              </td>
              <td data-label="Description" v-html="category.description"></td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Status
              </td>
              <td data-label="Status">
                {{ category.status == 1 ? 'Active' : 'Inactive' }}
              </td>
            </tr>
            <tr>
              <td class="
                  p-4
                  pl-8
                  text-slate-500
                  dark:text-slate-400
                  hidden
                  lg:block
                ">
                Created
              </td>
              <td data-label="Created">
                {{ new Date(category.created_at).toLocaleString() }}
              </td>
            </tr>
          </tbody>
        </table>
      </CardBox>
    </SectionMain>
  </LayoutAuthenticated>
</template>
