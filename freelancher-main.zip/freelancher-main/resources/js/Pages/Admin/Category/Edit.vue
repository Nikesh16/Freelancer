<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import {
  mdiAccountKey,
  mdiArrowLeftBoldOutline
} from "@mdi/js"
import LayoutAuthenticated from "@/Layouts/LayoutAuthenticated.vue"
import SectionMain from "@/Components/SectionMain.vue"
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue"
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import FormCheckRadioGroup from '@/Components/FormCheckRadioGroup.vue'
import BaseDivider from '@/Components/BaseDivider.vue'
import BaseButton from '@/Components/BaseButton.vue'
import BaseButtons from '@/Components/BaseButtons.vue'
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import FormFilePicker from "@/Components/FormFilePicker.vue"

const props = defineProps({
  category: {
    type: Object,
    default: () => ({}),
  },
  // blog_category: {
  //   type: Object,
  //   default: () => ({}),
  // },
})

const form = useForm({
  _method: 'put',
  name: props.category.name,
  description: props.category.description,
  image: '',
  meta_title: props.category.meta_title,
  meta_description: props.category.meta_description,
  meta_keyword: props.category.meta_keyword,
  status: props.category.status == 1 ? true : false,
  is_location_required: props.category.is_location_required ==1?true:false,
})
</script>

<template>
  <LayoutAuthenticated>

    <Head title="Update Category" />
    <SectionMain>
      <SectionTitleLineWithButton :icon="mdiAccountKey" title="Update Category" main>
        <BaseButton :route-name="route('admin.category.index')" :icon="mdiArrowLeftBoldOutline" label="Back" color="white"
          rounded-full small />
      </SectionTitleLineWithButton>
      <CardBox form @submit.prevent="form.post(route('admin.category.update', props.category.id))">
        <FormField label="Name" :class="{ 'text-red-400': form.errors.name }">
          <FormControl v-model="form.name" type="text" placeholder="Enter Name" :error="form.errors.name">
            <div class="text-red-400 text-sm" v-if="form.errors.name">
              {{ form.errors.name }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Description" :class="{ 'text-red-400': form.errors.description }">

          <quill-editor v-model:content="form.description" name="description" toolbar="full" theme="snow"
            contentType="html"></quill-editor>
        </FormField>

        <FormField label="Meta title" :class="{ 'text-red-400': form.errors.meta_title }">
          <FormControl v-model="form.meta_title" type="text" placeholder="Enter meta title"
            :error="form.errors.meta_title">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_title">
              {{ form.errors.meta_title }}
            </div>
          </FormControl>
        </FormField>
        <FormField label="Phone" :class="{ 'text-red-400': form.errors.meta_description }">
          <FormControl v-model="form.meta_description" type="text" placeholder="Enter meta description"
            :error="form.errors.meta_description">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_description">
              {{ form.errors.meta_description }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Meta Keywords" :class="{ 'text-red-400': form.errors.meta_keyword }">
          <FormControl v-model="form.meta_keyword" type="text" placeholder="Enter meta keyword"
            :error="form.errors.meta_keyword">
            <div class="text-red-400 text-sm" v-if="form.errors.meta_keyword">
              {{ form.errors.meta_keyword }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Image" :class="{ 'text-red-400': form.errors.image }">
          <FormFilePicker placeholder="Image" v-model="form.image" :error="form.errors.image" type="file" />
          <div class="text-red-400 text-sm" v-if="form.errors.image">
            {{ form.errors.image }}
          </div>
        </FormField>

        <FormCheckRadioGroup v-model="form.status" name="sample-switch" type="switch" class="mt-5"
          :options="{ two: 'Status' }" />

          <FormCheckRadioGroup v-model="form.is_location_required" name="sample-switch" type="switch" class="mt-5"
          :options="{ two: 'Location Required' }" />

        <template #footer>
          <BaseButtons>
            <BaseButton type="submit" color="info" label="Submit" :class="{ 'opacity-25': form.processing }"
              :disabled="form.processing" />
          </BaseButtons>
        </template>
      </CardBox>
    </SectionMain>
  </LayoutAuthenticated>
</template>
