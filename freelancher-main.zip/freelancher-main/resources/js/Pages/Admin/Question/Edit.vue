<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import {
  mdiAccountKey,
  mdiArrowLeftBoldOutline
} from "@mdi/js"
import LayoutAuthenticated from "@/Layouts/LayoutAuthenticated.vue"
import SectionMain from "@/Components/SectionMain.vue"
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue"
import CardBox from "@/Components/CardBox.vue"
import FormField from '@/Components/FormField.vue'
import FormControl from '@/Components/FormControl.vue'
import FormCheckRadioGroup from '@/Components/FormCheckRadioGroup.vue'
import BaseDivider from '@/Components/BaseDivider.vue'
import BaseButton from '@/Components/BaseButton.vue'
import BaseButtons from '@/Components/BaseButtons.vue'
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import FormFilePicker from "@/Components/FormFilePicker.vue"
import ObjectSelectFormControl from "@/Components/ObjectSelectFormControl.vue"

const props = defineProps({
  category: {
    type: Object,
    default: () => ({}),
  },
  question: {
    type: Object,
    default: () => ({}),
  },
  QuestionOption: {
    type: Object,
    default: () => ({}),
  },
})

const form = useForm({
  _method: 'put',
  question: props.question.question,
  input_type: props.question.input_type,
  is_required: props.question.is_required==1?true:false,
  placeholder: props.question.placeholder,
  meta_description: props.question.meta_description,
  meta_keyword: props.question.meta_keyword,
  status: props.question.status==1?true:false,
  category_id: props.question.question_category.category_id,
  label: props.question.label,
  options:props.QuestionOption,
});

const addMore = () => {
  form.options.push({ 'name': '', 'value': '' })
}
const removeService = (index) => {
  if (form.options.length > 1)
    form.options.splice(index, 1);
  else
    console.log("Feature array is empty, nothing to remove.");
}

const InputType = ['text', 'date', 'number', 'time', 'checkbox', 'radio', 'file', 'editor', 'textarea'];
</script>

<template>
  <LayoutAuthenticated>

    <Head title="Update Question" />
    <SectionMain>
      <SectionTitleLineWithButton :icon="mdiAccountKey" title="Update Question" main>
        <BaseButton :route-name="route('admin.question.index')" :icon="mdiArrowLeftBoldOutline" label="Back" color="white"
          rounded-full small />
      </SectionTitleLineWithButton>
      <CardBox form @submit.prevent="form.post(route('admin.question.update', props.question.id))">
        <FormField label="Question" :class="{ 'text-red-400': form.errors.question }">
          <FormControl v-model="form.question" type="text" placeholder="Enter Question" :error="form.errors.question">
            <div class="text-red-400 text-sm" v-if="form.errors.question">
              {{ form.errors.question }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Category" :class="{ 'text-red-400': form.errors.category_id }">
          <FormControl v-model="form.category_id" ankcustomclass :options="category" required>
            <div class="text-red-400 text-sm" v-if="form.errors.category_id">
              {{ form.errors.category_id }}
            </div>
          </FormControl>
        </FormField>

        <FormField label="Input Type" :class="{ 'text-red-400': form.errors.input_type }">
          <ObjectSelectFormControl v-model="form.input_type" :options="InputType" required>
            <div class="text-red-400 text-sm" v-if="form.errors.input_type">
              {{ form.errors.input_type }}
            </div>
          </ObjectSelectFormControl>
        </FormField>

        <div v-if="form.input_type == 'checkbox' || form.input_type == 'radio'">
          <div class="title font-bold pb-3">Options</div>
          <table class="table mb-3 ">
            <thead class="bg-gray-200 dark:bg-slate-700 rounded-t-lg top">
              <tr>
                <th class="border-r">Name</th>
                <th class="border-r">Value</th>
                <th class="border-r">Remove</th>
              </tr>
            </thead>
            <tbody v-for="(ser, index) in form.options" :key="'ser' + index">
              <tr class="border-bimp">
                <td data-label="Name">
                  <FormField>
                    <FormControl v-model="ser['name']" type="text" placeholder="Enter Name">
                    </FormControl>
                  </FormField>
                </td>
                <td data-label="Icon">
                  <FormField>
                    <FormControl v-model="ser['value']" type="text" placeholder="Enter Name">
                    </FormControl>
                  </FormField>
                </td>
                <td class="text-right" data-label="Delete Options">
                  <div v-if="form.options.length > 1" @click.prevent="removeService(index)"
                    class=" w-11 h-11 cursor-pointer shadow-md flex justify-center items-center rounded-md hover:bg-red-500 group duration-500">
                    <i class="fa fa-trash text-red-900 group-hover:text-white"></i>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <div class="flex flex-wrap gap-3 mb-3  lg:mt-0 mt-3">
            <div class=" text-left"><button class="btn-fill-green" @click.prevent="addMore()">Add
                Options</button>
            </div>
          </div>
        </div>

        <FormField label="Placeholder" :class="{ 'text-red-400': form.errors.placeholder }">
          <FormControl v-model="form.placeholder" type="text" placeholder="Enter Placeholder"
            :error="form.errors.placeholder">
            <div class="text-red-400 text-sm" v-if="form.errors.placeholder">
              {{ form.errors.placeholder }}
            </div>
          </FormControl>
        </FormField>
        <FormField label="label" :class="{ 'text-red-400': form.errors.label }">
          <FormControl v-model="form.label" type="text" placeholder="Enter label" :error="form.errors.label">
            <div class="text-red-400 text-sm" v-if="form.errors.label">
              {{ form.errors.label }}
            </div>
          </FormControl>
        </FormField>

        <FormCheckRadioGroup v-model="form.status" name="sample-switch" type="switch" class="mt-5"
          :options="{ two: 'Status' }" />
        <FormCheckRadioGroup v-model="form.is_required" name="sample-switch" type="switch" class="mt-5"
          :options="{ two: 'Required' }" />

        <BaseDivider />

        <template #footer>
          <BaseButtons>
            <BaseButton type="submit" color="info" label="Submit" :class="{ 'opacity-25': form.processing }"
              :disabled="form.processing" />
          </BaseButtons>
        </template>
      </CardBox>
    </SectionMain>
  </LayoutAuthenticated>
</template>
