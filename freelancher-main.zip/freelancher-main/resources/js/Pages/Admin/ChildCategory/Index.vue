<script setup>
import { Head, Link, useForm } from "@inertiajs/vue3"
import {
  mdiAccountKey,
  mdiPlus,
  mdiSquareEditOutline,
  mdiTrashCan,
  mdiAlertBoxOutline,
} from "@mdi/js"
import LayoutAuthenticated from "@/Layouts/LayoutAuthenticated.vue"
import SectionMain from "@/Components/SectionMain.vue"
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue"
import BaseButton from "@/Components/BaseButton.vue"
import CardBox from "@/Components/CardBox.vue"
import BaseButtons from "@/Components/BaseButtons.vue"
import NotificationBar from "@/Components/NotificationBar.vue"
import Pagination from "@/Components/Admin/Pagination.vue"
import Sort from "@/Components/Admin/Sort.vue"

const props = defineProps({
  categories: {
    type: Object,
    default: () => ({}),
  },
  filters: {
    type: Object,
    default: () => ({}),
  },
})

const form = useForm({
  search: props.filters.search,
})

const formDelete = useForm({})

function destroy(id) {
  if (confirm("Are you sure you want to delete?")) {
    formDelete.delete(route("admin.child_category.destroy", id))
  }
}
</script>

<template>
  <LayoutAuthenticated>

    <Head title="Child Category" />
    <SectionMain>
      <SectionTitleLineWithButton :icon="mdiAccountKey" title="Child Category" main>
        <BaseButton :route-name="route('admin.child_category.create')" :icon="mdiPlus" label="Add" color="info"
          rounded-full small />
      </SectionTitleLineWithButton>
      <NotificationBar :key="Date.now()" v-if="$page.props.flash.message" color="success" :icon="mdiAlertBoxOutline">
        {{ $page.props.flash.message }}
      </NotificationBar>
      <CardBox class="mb-6" has-table>
        <form @submit.prevent="form.get(route('admin.child_category.index'))">
          <div class="py-2 flex">
            <div class="flex pl-4">
              <input type="search" v-model="form.search" class="
                  rounded-md
                  shadow-sm
                  border-gray-300
                  focus:border-indigo-300
                  focus:ring
                  focus:ring-indigo-200
                  focus:ring-opacity-50
                " placeholder="Search" />
              <BaseButton label="Search" type="submit" color="info" class="ml-4 inline-flex items-center px-4 py-2" />
            </div>
          </div>
        </form>
      </CardBox>
      <CardBox class="mb-6" has-table>
        <table>
          <thead>
            <tr>
              <th>
                <Sort label="Name" attribute="name" />
              </th>
              <th>
                <Sort label="Meta Title" attribute="meta_title" />
              </th>
              <th>
                <Sort label="Status" attribute="status" />
              </th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="category in categories.data" :key="category.id">
              <td data-label="Name">
                <Link :href="route('admin.category.show', category.id)" class="
                    no-underline
                    hover:underline
                    text-cyan-600
                    dark:text-cyan-400
                  ">
                {{ category.name }}
                </Link>
              </td>
              <td data-label="Meta Title">
                {{ category.meta_title }}
              </td>
              <td data-label="Status">
                {{ category.status == 1 ? 'Active' : 'Inactive' }}
              </td>

              <td class="before:hidden lg:w-1 whitespace-nowrap">
                <BaseButtons type="justify-start lg:justify-end" no-wrap>
                  <BaseButton :route-name="route('admin.category.edit', category.id)" color="info" :icon="mdiSquareEditOutline"
                    small />
                  <BaseButton color="danger" :icon="mdiTrashCan" small @click="destroy(category.id)" />
                </BaseButtons>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="py-4">
          <Pagination :data="categories" />
        </div>
      </CardBox>
    </SectionMain>
  </LayoutAuthenticated>
</template>
