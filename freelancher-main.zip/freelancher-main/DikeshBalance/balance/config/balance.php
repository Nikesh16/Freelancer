<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Table name
    |--------------------------------------------------------------------------
    |
    | Table name to use to store balance history transactions.
    |
    */

    'table' => 'balance_history',

];
